package com.example.roberto.editar.Utils;

import com.example.roberto.editar.R;

/**
 * Definición de todas las constantes de la Interfaz de usuario
 */
public final class ID {
//    public static final int BOTON_TRABAJO = R.id.button2;
//    public static final int BOTON_IMAGENES = R.id.button3;
//    public static final int BOTON_MONEDERO = R.id.button14;


}
