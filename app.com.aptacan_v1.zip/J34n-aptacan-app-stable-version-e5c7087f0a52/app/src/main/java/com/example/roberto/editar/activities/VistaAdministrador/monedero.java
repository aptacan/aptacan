package com.example.roberto.editar.activities.VistaAdministrador;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.roberto.editar.R;

import java.util.Locale;

import butterknife.ButterKnife;
import butterknife.OnClick;

public class monedero extends Activity {

    private Integer[] caja = new Integer[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    private double total=0.0;
    SharedPreferences preferencias;
    MediaPlayer mMediaPlayer;

    @OnClick({R.id.imageButton13, R.id.imageButton14, R.id.imageButton15, R.id.imageButton16,
            R.id.imageButton17, R.id.imageButton18, R.id.imageButton19, R.id.imageButton20,
            R.id.imageButton21, R.id.imageButton22, R.id.imageButton23, R.id.imageButton24, R.id.button12})
    public void onClick(View v) {

//        if(mMediaPlayer.isPlaying())
//            mMediaPlayer.pause();
//        else
//            mMediaPlayer.start();

        final int[] imagenes = {R.id.imageButton13, R.id.imageButton14, R.id.imageButton15, R.id.imageButton16,
                R.id.imageButton17, R.id.imageButton18, R.id.imageButton19, R.id.imageButton20,
                R.id.imageButton21, R.id.imageButton22, R.id.imageButton23, R.id.imageButton24, R.id.button12};


        int num = -1;
        switch (v.getId()) {
            case R.id.imageButton13: {
                num = 0;
                break;
            }
            case R.id.imageButton14: {
                num = 1;
                break;
            }
            case R.id.imageButton15: {
                num = 2;
                break;
            }
            case R.id.imageButton16: {
                num = 3;
                break;
            }
            case R.id.imageButton17: {
                num = 4;
                break;
            }
            case R.id.imageButton18: {
                num = 5;
                break;
            }
            case R.id.imageButton19: {
                num = 6;
                break;
            }
            case R.id.imageButton20: {
                num = 7;
                break;
            }
            case R.id.imageButton21: {
                num = 8;
                break;
            }
            case R.id.imageButton22: {
                num = 9;
                break;
            }
            case R.id.imageButton23: {
                num = 10;
                break;
            }
            case R.id.imageButton24: {
                num = 11;
                break;
            }
            case R.id.button12: {
                num=-1;
                break;
            }
            default: {
                break;
            }
        }
        anadirdinero(num);
    }






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferencias = getSharedPreferences("Monedero", MODE_PRIVATE);
        setContentView(R.layout.activity_monedero);
        ButterKnife.bind(this);
        Integer[] medidas;
        medidas = measurescreen();
        cargarimagenes(100, 100);
        Cargarmonedero();
//        mMediaPlayer = MediaPlayer.create(this, R.raw.sonido_monedas);
        Log.i("<ACTIVIDAD>", "[_____ CARGAR MONEDERO _____]");
    }



    private Integer[] measurescreen() {
        Integer[] medidas = new Integer[2];
        WindowManager wm = (WindowManager) this.getApplicationContext().getSystemService(WINDOW_SERVICE);

        Display display = wm.getDefaultDisplay();
        int screenWidth;
        int screenHeight;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            Point size = new Point();
            display.getSize(size);
            screenWidth = size.x;
            screenHeight = size.y;
        } else {
            screenWidth = display.getWidth();
            screenHeight = display.getHeight();
        }
        float x;
        float y;
        x = screenWidth / 10;
        y = screenHeight / 10;
        medidas[0] = (int) x;
        medidas[1] = (int) y;
        return medidas;
    }


    private void cargarimagenes(int x, int y) {
        int i;
        Integer[] contentimage = {R.id.imageButton13, R.id.imageButton14, R.id.imageButton15, R.id.imageButton16, R.id.imageButton17, R.id.imageButton18, R.id.imageButton19, R.id.imageButton20, R.id.imageButton21, R.id.imageButton22, R.id.imageButton23, R.id.imageButton24};
        Integer[] images = {R.drawable.uncent, R.drawable.doscent, R.drawable.cincocent, R.drawable.diezcent, R.drawable.veintecent, R.drawable.cincuentacent, R.drawable.uneuro, R.drawable.doseuro, R.drawable.cincoeuro, R.drawable.diezeuro, R.drawable.veinteeuro, R.drawable.cincuentaeuro};
        for (i = 0; i < 12; i++) {
            ImageView image = (ImageView) findViewById(contentimage[i]);
            Glide.with(image.getContext())
                    .load(images[i])
                    .apply(new RequestOptions().override(x, y))
                    .into(image);
        }
    }



    private void anadirdinero(int cambio) {
        if (cambio!=-1){
            double cantidad;
            Integer[] txts = new Integer[]{R.id.textView34, R.id.textView35, R.id.textView36, R.id.textView37, R.id.textView38, R.id.textView39,
                    R.id.textView40, R.id.textView41, R.id.textView42, R.id.textView43, R.id.textView44, R.id.textView45};
            String[] valores = new String[]{"uncent", "doscent", "cincocent", "diezcent", "veintecent", "cincuentacent",
                    "uneuro", "doseuros", "cincoeuros", "diezeuros", "veinteeuros","cincunetaeuros"};
            caja[cambio]++;
            TextView txt = (TextView) findViewById(txts[cambio]);
            txt.setText(String.format(Locale.getDefault(), "%d",caja[cambio]));
            txt = (TextView) findViewById(R.id.totalmonedero);
            cantidad=obtenervalor(cambio);
            total = total + cantidad;
            txt.setText((String.format(Locale.getDefault(),"%.2f Euros", total)));
            SharedPreferences.Editor editor = preferencias.edit();
            editor.putInt(valores[cambio],preferencias.getInt(valores[cambio],0)+1);
            editor.apply();
        }
        else{
            SharedPreferences.Editor editor = preferencias.edit();
            editor.putBoolean("Existe",false);
            editor.apply();
            Cargarmonedero();
        }

    }



    private void rellenartxt() {
        Integer[] txts = new Integer[]{R.id.textView34, R.id.textView35, R.id.textView36, R.id.textView37, R.id.textView38, R.id.textView39,
                R.id.textView40, R.id.textView41, R.id.textView42, R.id.textView43, R.id.textView44, R.id.textView45};
        for (int i = 0; i < 12; i++) {
            TextView txt = (TextView) findViewById(txts[i]);
            txt.setText(String.format(Locale.getDefault(), "%d", caja[i]));
        }
        TextView txt = (TextView) findViewById(R.id.totalmonedero);
        txt.setText(String.format(Locale.getDefault(), "%.2f", total));

    }



    public double obtenervalor(int num){
        double multiplicador;
        switch (num){
            case 0: {
                multiplicador=0.01;
                break;
            }
            case 1: {
                multiplicador=0.02;
                break;
            }
            case 2: {
                multiplicador=0.05;
                break;
            }
            case 3: {
                multiplicador=0.1;
                break;
            }
            case 4: {
                multiplicador=0.2;
                break;
            }
            case 5: {
                multiplicador=0.5;
                break;
            }
            case 6: {
                multiplicador=1;
                break;
            }
            case 7: {
                multiplicador=2;
                break;
            }
            case 8: {
                multiplicador=5;
                break;
            }
            case 9: {
                multiplicador=10;
                break;
            }
            case 10: {
                multiplicador=20;
                break;
            }
            case 11: {
                multiplicador=50;
                break;
            }
            default: {
                multiplicador = 0;
                break;
            }
        }
        return multiplicador;
    }



    private void Cargarmonedero(){
        boolean existe = preferencias.getBoolean("Existe", false);
        String[] valores = new String[]{"uncent", "doscent", "cincocent", "diezcent",
                "veintecent", "cincuentacent", "uneuro", "doseuros", "cincoeuros", "diezeuros",
                "veinteeuros","cincunetaeuros"};
        if (existe) {
            for (int i = 0; i < 12; i++) {
                Integer cantidad = preferencias.getInt(valores[i], 0);
                double multiplicador = obtenervalor(i);
                caja[i] = cantidad;
                total = total + cantidad * multiplicador;
            }

        } else {
            SharedPreferences.Editor editor = preferencias.edit();
            for (int i = 0; i < 12; i++) {
                caja[i]=0;
                editor.putInt(valores[i], 0);
            }
            editor.putBoolean("Existe", true);
            editor.apply();
            total=0;
        }
        rellenartxt();
    }


}
