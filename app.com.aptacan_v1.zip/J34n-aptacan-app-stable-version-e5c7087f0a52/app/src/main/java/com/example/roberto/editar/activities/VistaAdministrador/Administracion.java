package com.example.roberto.editar.activities.VistaAdministrador;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.ID;
import com.example.roberto.editar.activities.VistaAdministrador.Fragments.GaleriaDeImagenes;
import com.example.roberto.editar.activities.VistaAdministrador.Fragments.ListaDeTrabajos;
import com.example.roberto.editar.activities.VistaAdministrador.Fragments.MonederoCaja;

import butterknife.ButterKnife;
import butterknife.OnClick;

public class Administracion extends AppCompatActivity {


    private BottomNavigationView navigationView;



    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        navigationView.setSelectedItemId(R.id.boton_menu_trabajos);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        setContentView(R.layout.activity_administracion);
        ButterKnife.bind(this);

        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        navigationView = findViewById(R.id.bottom_navigation_admin);


        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {

                    case R.id.boton_menu_imagenes:
                        GaleriaDeImagenes galeriaDeImagenes = new GaleriaDeImagenes();
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.contenedor_administracion, galeriaDeImagenes)
                                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_CLOSE)
                                .addToBackStack(null).commit();
                        return true;
                    case R.id.boton_menu_trabajos:
                        ListaDeTrabajos listaDeTrabajos = new ListaDeTrabajos();
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.contenedor_administracion, listaDeTrabajos)
                                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_CLOSE)
                                .addToBackStack(null).commit();
                        return true;
                    case R.id.boton_menu_modero:
                        MonederoCaja monederoCaja = new MonederoCaja();
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.contenedor_administracion, monederoCaja)
                                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_CLOSE)
                                .addToBackStack(null).commit();
                        return true;
                }
                return false;
            }
        });
        super.onCreate(savedInstanceState);
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_administracion, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            finish();//return true;
        } else if(id == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }







}
