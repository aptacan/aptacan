package com.example.roberto.editar.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.roberto.editar.R;
import com.example.roberto.editar.activities.VistaAdministrador.Administracion;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class Acceso extends AppCompatActivity {

    @BindView(R.id.editText) EditText editText_usuario;
    @BindView(R.id.editText2) EditText editText_password;
    @BindView(R.id.textView3) TextView textView_error;
    @BindView(R.id.button) Button boton_acceder;



    @OnClick(R.id.button)
    public void AutenticarUsuario(View view) {
        final String nombre = String.valueOf(editText_usuario.getText());
        final String password = String.valueOf(editText_usuario.getText());

        if(esUsuarioValido(nombre, password)) {
            Intent intent = new Intent(Acceso.this, Administracion.class);
            startActivity(intent);
            finish();
        } else {
            textView_error.setVisibility(View.VISIBLE);
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acceso);
        ButterKnife.bind(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_acceso, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //usuario registrado defaut: [usuario: ""], [password: ""]
    public boolean esUsuarioValido(String usuario, String password) {
        return "".equals(usuario) && "".equals(password);
    }
}
