package com.example.roberto.editar.adapters;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.roberto.editar.R;

import java.util.ArrayList;

/**
 * Created by Roberto on 30/10/2015.
 */
public class GridViewAdapter extends ArrayAdapter<String> {

    private Context context;
    private int layoutResourceId;
    private ArrayList<String> data;




    public GridViewAdapter(Context context, int layoutResourceId, ArrayList<String> data) {
        super(context, layoutResourceId, data);

        this.layoutResourceId = layoutResourceId;
        this.context = context;
        this.data = data;
    }



    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        Log.i("<Evento getVIEW>: ","????????EJECUTADO??????????");
        View row = convertView;
        ViewHolder holder;
        String item = data.get(position);

        if (row == null) {
            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
            row = inflater.inflate(layoutResourceId, parent, false);

            holder = new ViewHolder();
            holder.imageTitle = row.findViewById(R.id.text);
            holder.image = row.findViewById(R.id.image);
            row.setTag(holder);
        } else {
            holder = (ViewHolder) row.getTag();
        }

        final String nombreDeImagen = item.substring(
                item.lastIndexOf("/") + 1,
                item.length()
        );

        holder.imageTitle.setText(nombreDeImagen);

        Glide.with(holder.image.getContext())
                .load(item)
                .into(holder.image);

        return row;
    }



    public void remove(int position) {
        data.remove(position);
        notifyDataSetChanged();
    }


    public void update(ArrayList<String> nuevosDatos) {
        data = nuevosDatos;
        notifyDataSetChanged();
    }



    static class ViewHolder {
        TextView imageTitle;
        ImageView image;
    }
}
