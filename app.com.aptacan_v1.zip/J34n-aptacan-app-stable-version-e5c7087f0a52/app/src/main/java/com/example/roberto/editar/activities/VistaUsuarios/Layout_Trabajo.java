package com.example.roberto.editar.activities.VistaUsuarios;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.IntDef;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.DbControl;
import com.example.roberto.editar.Utils.Utiles;
import com.example.roberto.editar.models.ElementsWorks;
import com.example.roberto.editar.models.ElementsWorksRead;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static android.util.Log.i;

public class   Layout_Trabajo extends Activity implements View.OnClickListener {


    //para la consulta de obtener datos
    @Retention(RetentionPolicy.SOURCE)
    @IntDef({
            DATOS.NombreDato,
            DATOS.Icono,
            DATOS.Precio,
    })
    public @interface DATOS {
        int NombreDato = 0;
        int  Icono = 1;
        int Precio = 2;
    }


    //para consulta de trabajos
    @Retention(RetentionPolicy.SOURCE)
    @IntDef({
            TRABAJO.Id,
            TRABAJO.Trabajo,
            TRABAJO.posicion,
            TRABAJO.prompt,
    })
    public @interface TRABAJO {
        int Id = 0;
        int Trabajo = 1;
        int elemento = 2;
        int posicion = 3;
        int prompt = 4;
    }


    @Retention(RetentionPolicy.SOURCE)
    public @interface Recursos {
        int[] Iconos = {
                R.id.rlouicono,
                R.id.rlouicono2,
                R.id.rlouicono3,
                R.id.rlouicono4,
                R.id.rlouicono5
        };

        int[] Precios = {
                R.id.rlouprecio,
                R.id.rlouprecio2,
                R.id.rlouprecio3,
                R.id.rlouprecio4,
                R.id.rlouprecio5
        };
    }


    private LinearLayout layoutElementos;
    private String trabajoElegido;
    private DbControl dbadapter;
    private Integer idworkread;
    private Context contexto;

    private boolean isDobleCaraActivated = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setBotonRetrocesoEnActionBar();
        setLayoutPrincipal();

        isDobleCaraActivated = false; // seteando a su estado normal
        trabajoElegido = getIntent().getStringExtra("trabajo");
        setTitle(trabajoElegido);

        dbadapter = new DbControl(this);

        obtener_idworkread();
        Cargar_Archivos();
        agregarBoton();
    }



    private void setBotonRetrocesoEnActionBar() {
        final ActionBar actionBar = getActionBar();
        if(actionBar != null)
            actionBar.setDisplayHomeAsUpEnabled(true);
    }



    private void setLayoutPrincipal() {
        RelativeLayout layoutPrincipal = new RelativeLayout(this);
        ScrollView scrollView = new ScrollView(this);
        layoutElementos = new LinearLayout(this);

        layoutElementos.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(layoutElementos);
        layoutPrincipal.addView(scrollView);

        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );

        layoutParams.setMargins(50, 100, 50, 0);
        layoutElementos.setLayoutParams(layoutParams);



        setContentView(layoutPrincipal);

    }



    private void agregarBoton() {
        View inflatedLayout;

        if (layoutElementos.getChildCount() == 0) {

            inflatedLayout = getLayoutInflater().inflate(
                    R.layout.sinelementos,
                    null,
                    true
            );
            layoutElementos.addView(inflatedLayout);
            i(this.getLocalClassName(), "[[]] -> agregacion del boton" );
        }

        inflatedLayout = getLayoutInflater().inflate(R.layout.botonlayout, null, true);
        layoutElementos.addView(inflatedLayout);

        Button button_Cancelar = findViewById(R.id.button_cancelar);
        button_Cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Layout_Trabajo.this, Menu_Trabajos.class);
                startActivity(intent);
                finish();
            }
        });

        Button button_aceptar = findViewById(R.id.button9); //boton ACEPTAR
        button_aceptar.setOnClickListener(this);
    }




    @Override
    public void onClick(View view) {
        contexto = view.getContext();
        Integer datain = 0;
        ArrayList<ElementsWorksRead> elementosleidos = new ArrayList<>();
        //ElementsWorksRead elemento=new ElementsWorksRead(0,0,"","",0);
        final int cantidadElementosDibujados = layoutElementos.getChildCount();

        for (int i = 0; i < cantidadElementosDibujados; i++) {

            View layoutElemento = layoutElementos.getChildAt(i);
            Integer id_layoutElemento = layoutElemento.getId();
            i("Vista ejecutado.", "vista: " + layoutElemento.getId() + "\tvistatag: " + layoutElemento.getTag());
            String dato;
            String icono;
            String precio;
            EditText editText;
            int cantidad = 0;

            switch (id_layoutElemento) {
                case R.id.rlen:
                    editText = layoutElemento.findViewById(R.id.editText);
                    dato = editText.getText().toString();
                    //([0-9]+-[0-9]+)|[0-9]+

                    if (dato.matches("([0-9]+-[0-9]+)|[0-9]+")) {


                        cantidad = getValorRango(dato);
                        Log.i("RAGNO>>>>>", "cantidad: " + cantidad);


                        if (dato.contentEquals("")) {
                            datain = 1;
                            Log.e("SSSSSSS", "setenaod dato en 1-------");
                        } else {
                            try {
                                Log.e("SSSSSSS", "-----ahora si puedo entrar-------");
                                TextView texto = layoutElemento.findViewById(R.id.rlenicono);

                                //seteando datos
                                icono = texto.getText().toString();
                                texto = layoutElemento.findViewById(R.id.rlenprecio);
                                precio = texto.getText().toString();
                                precio = precio.replace(",", ".");


                                ElementsWorksRead elemento = new ElementsWorksRead(
                                        0,
                                        idworkread,
                                        dato,
                                        icono,
                                        Float.parseFloat(precio),
                                        cantidad
                                );
                                elementosleidos.add(elemento);
                            } catch (Exception e) {
                                Toast.makeText(Layout_Trabajo.this, e.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    } else {
                        datain = 1;
                        Toast.makeText(Layout_Trabajo.this, "Ingresa una entrada numérica correcta", Toast.LENGTH_SHORT).show();
                    }
                    break;

                case R.id.rlsec:
                    editText =  layoutElemento.findViewById(R.id.editText2);

                    dato = editText.getText().toString();
                    if (dato.contentEquals("")) {
                        datain = 1; //bandera: ya han sido ingresados datos.
                    } else {
                        try{
                            //intentando
                            if (!dato.matches("(\\d|\\d-\\d)(,(\\d|\\d-\\d))*")) {
                                throw new Exception("La secuencia no es del tipo 4,6-10 o similar");
                            }
                            TextView texto = (TextView) layoutElemento.findViewById(R.id.rlenmlicono);

                            //seteando datos
                            icono = texto.getText().toString();
                            texto = (TextView) layoutElemento.findViewById(R.id.rlenmlprecio);
                            precio = texto.getText().toString();
                            precio = precio.replace(",", ".");

                            ElementsWorksRead elemento = new ElementsWorksRead(
                                    10+R.id.rlsec,
                                    idworkread,
                                    dato,
                                    icono,
                                    Float.parseFloat(precio),
                                    1
                            );
                            elementosleidos.add(elemento);
                        }
                        catch(Exception e){
                            Toast.makeText(Layout_Trabajo.this, e.toString(), Toast.LENGTH_SHORT).show();
                        }

                    }
                    break;

                case R.id.rlenml:
                    EditText editText1 = (EditText) layoutElemento.findViewById(R.id.editText2);
                    dato = editText1.getText().toString();
                    if (dato.contentEquals("")) {
                        datain = 1;
                    } else {
                        TextView texto = (TextView) layoutElemento.findViewById(R.id.rlenmlicono);

                        //seteando datos
                        icono = texto.getText().toString();
                        texto = (TextView) layoutElemento.findViewById(R.id.rlenmlprecio);
                        precio = texto.getText().toString();
                        precio = precio.replace(",", ".");

                        ElementsWorksRead elemento = new ElementsWorksRead(
                                0,
                                idworkread,
                                dato,
                                icono,
                                Float.parseFloat(precio),
                                0
                        );
                        elementosleidos.add(elemento);
                    }
                    break;

                case R.id.rlou:
                    RadioGroup radiogroup =  layoutElemento.findViewById(R.id.rg);
                    RadioButton radiobutton = findViewById(radiogroup.getCheckedRadioButtonId());

                    Integer idrb = radiogroup.getCheckedRadioButtonId();
                    Integer posicion = posradiogroup(idrb);
                    dato = radiobutton.getText().toString();

                    TextView texto = (TextView) layoutElemento.findViewById(Recursos.Iconos[posicion]);

                    //seteando datos
                    icono = texto.getText().toString();
                    texto = (TextView) layoutElemento.findViewById(Recursos.Precios[posicion]);
                    precio = texto.getText().toString();
                    precio = precio.replace(",", ".");

                    ElementsWorksRead elemento = new ElementsWorksRead(0, idworkread, dato, icono, Float.parseFloat(precio),0);
                    elementosleidos.add(elemento);
                    int conador = 2;
                    break;

                case R.id.rlelegibles:
                    i("[ELEGIBLES]: ", "CUANTAS VESES ------->>>>>>");
                    CheckBox elegible = (CheckBox) layoutElemento.findViewById(R.id.elegiblescb);

                    if (elegible.isChecked()) {
                        dato = elegible.getText().toString();

                        if (!isDobleCaraActivated)
                            isDobleCaraActivated = isDobleCara(dato);

                        Log.i("<Doble cara>", "es Doble cara (Elegibles)? : " + isDobleCaraActivated);

                        TextView textoe = (TextView) layoutElemento.findViewById(R.id.rlelegiblesicono);

                        //seteando datos
                        icono = textoe.getText().toString();
                        textoe = (TextView) layoutElemento.findViewById(R.id.rlelegiblesprecio);
                        precio = textoe.getText().toString();
                        precio = precio.replace(",", ".");

                        ElementsWorksRead elementoe = new ElementsWorksRead(0, idworkread, dato, icono, Float.parseFloat(precio),0);
                        elementosleidos.add(elementoe);
                    }
                    break;

                case R.id.rldespegables:
                    Integer[] idiconod = {
                            R.id.rldespegablesicono,
                            R.id.rldespegablesicono2,
                            R.id.rldespegablesicono3,
                            R.id.rldespegablesicono4,
                            R.id.rldespegablesicono5
                    };
                    Integer[] idpreciod = {
                            R.id.rldespegablesprecio,
                            R.id.rldespegablesprecio2,
                            R.id.rldespegablesprecio3,
                            R.id.rldespegablesprecio4,
                            R.id.rldespegablesprecio5
                    };
                    Spinner spiner = (Spinner) layoutElemento.findViewById(R.id.spinner);
                    Integer posd = spiner.getSelectedItemPosition();
                    dato = (String) spiner.getSelectedItem();
                    TextView textod = (TextView) layoutElemento.findViewById(idiconod[posd]);


                    if(!isDobleCaraActivated)
                        isDobleCaraActivated = isDobleCara(dato);
                    Log.i("<Doble cara>", "es Doble cara (Elegibles)? : " + isDobleCaraActivated);

                    //seteando datos
                    icono = textod.getText().toString();
                    texto = (TextView) layoutElemento.findViewById(idpreciod[posd]);
                    precio = texto.getText().toString();
                    precio = precio.replace(",", ".");

                    ElementsWorksRead elementod = new ElementsWorksRead(0, idworkread, dato, icono, Float.parseFloat(precio),0);
                    elementosleidos.add(elementod);
                    break;

                //boton acceptar pulsado
                case R.id.rlaceptar:
                    if (datain != 1) {
                        insertarWorkRead();
                        insertarElementsWorksRead(elementosleidos);

                        AlertDialog.Builder dialogo1 = new AlertDialog.Builder(view.getContext());
                        dialogo1.setTitle("IMPORTANTE");
                        dialogo1.setMessage("¿ Quieres realizar algún trabajo más?");
                        dialogo1.setCancelable(false);
                        dialogo1.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogo1, int id) {
                                incrementarIdWorkRead();
                                Intent intent = new Intent(Layout_Trabajo.this, Menu_Trabajos.class);
                                startActivity(intent);
                                finish();
                            }
                        });
                        dialogo1.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogo1, int id) {
                                eliminarpreferencias();
                                SharedPreferences preferencias = getSharedPreferences("WorksRead",MODE_PRIVATE);
                                SharedPreferences.Editor editor = preferencias.edit();
                                editor.putInt("idfin", idworkread);
                                editor.apply();
                                AlertDialog.Builder dialogo2 = new AlertDialog.Builder(contexto);

                                dialogo2.setTitle("POR FAVOR");
                                dialogo2.setMessage("Pase la tablet al trabajador");
                                dialogo2.setCancelable(false);
                                dialogo2.setPositiveButton("Trabajador", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialogo1, int id) {
                                        Intent intent = new Intent(Layout_Trabajo.this, ver_resultados.class);
                                        startActivity(intent);
                                        finish();
                                    }
                                });
                                dialogo2.show();
                            }
                        });
                        dialogo1.show();
                    } else {
                        AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                        builder.setTitle("Importante");
                        builder.setMessage("No estan todos los datos introducidos.");
                        builder.setPositiveButton("OK", null);
                        builder.create();
                        builder.show();
                    }
                    break;

                case R.id.rlno:
                    break;
            }
        }
    }




    private void incrementarIdWorkRead() {
        SharedPreferences preferencias = getSharedPreferences("WorksRead",MODE_PRIVATE);
        Integer id = preferencias.getInt("IdWorkRead", 1);
        Log.e("ID........", "idpreferecia: " + id);
        SharedPreferences.Editor editor = preferencias.edit();
        editor.putInt("IdWorkRead", id + 1);
        editor.apply();
    }



    private int getValorRango(String entradaRango) {
        if(entradaRango.contains("-")) {
            int inicio = Integer.parseInt(
                    entradaRango.substring(0, entradaRango.indexOf("-"))
            );
            int fin = Integer.parseInt(
                    entradaRango.substring(entradaRango.lastIndexOf("-") + 1)
            );
            return Math.abs(fin - inicio) + 1;
        }
//        if(entradaRango.equals(""))
//            return 0;

        return Integer.parseInt(entradaRango);
    }



    /**
     * Obtiene id del ultimo trabajo procesado y lo guarda como el id inicial de los trabajos
     * que se procesaran, escribiendolo en SharedPreferences.
     */
    private void obtener_idworkread() {
        DbControl db = new DbControl(this);
        db.open();

        this.idworkread = db.getMaxIdfromWorksRead() + 1; //el ultimo trabajo procesado
        Log.i("[obtener_idworkread()]", "[[ idworkread ]] -> " + this.idworkread);

        SharedPreferences preferencias = getSharedPreferences("WorksRead",MODE_PRIVATE);

        if (!preferencias.contains("idini")) {
            SharedPreferences.Editor editor = preferencias.edit();
            editor.putInt("idini", this.idworkread);
            editor.apply();
        }
    }



    private Integer posradiogroup(Integer seleccion){
//        final int[] hola = {R.id.radioButton, R.id.radioButton2, R.id.radioButton3, R.id.radioButton4, R.id.radioButton5};
        Integer pos = 0;
        switch (seleccion) {
            case R.id.radioButton:
                pos = 0;
                break;
            case R.id.radioButton2:
                pos = 1;
                break;
            case R.id.radioButton3:
                pos = 2;
                break;
            case R.id.radioButton4:
                pos = 3;
                break;
            case R.id.radioButton5:
                pos = 4;
                break;
        }
        return pos;

//        return 0;
    }



    private void insertarWorkRead() {
        ContentValues newvalue = new ContentValues();

        dbadapter.open();
        Cursor cursor = dbadapter.DatosWorkRead(trabajoElegido); //consulta datos del titulo de trabajo

        newvalue.put("_Id",idworkread);
        newvalue.put("Titulo",cursor.getString(1)); //Trabajo.titulo
        newvalue.put("Icono",cursor.getString(2)); //Trabajo.icono
        newvalue.put("Precio",cursor.getFloat(3)); //Trabajo.precio
        //copia dicho valor a tabla WorksRead
        dbadapter.Insertar("WorksRead",newvalue);
        dbadapter.close();
    }



    // devuelve en numero de veses que contiene, sino devuelve 0
    private int contieneString(ArrayList<ElementsWorksRead> elementos, String cadena) {
        int veses = 0;
        for (ElementsWorksRead elemento : elementos) {
            if(elemento.getDato().equals(cadena)) {
                veses++;
            }
        }
        return veses;
    }

    private boolean isDobleCara(String titulo) {
        return titulo.toLowerCase().contains("doble cara") || titulo.toLowerCase().contains("dos caras") ||
                titulo.toLowerCase().contains("cara doble") || titulo.toLowerCase().contains("2 caras");
    }



    //duplica el valor si, se ha seleccionado doble cara
    private ArrayList<ElementsWorksRead> AumentarValorDobleCara(ArrayList<ElementsWorksRead> elementos) {
        int limite = elementos.size();

        for(int i = 0; i < limite; i++) {

            ElementsWorksRead elemento = elementos.get(i);


                elementos.get(i).setPrecio(
                        elementos.get(i).getPrecio() * 2
                );

                Log.i("<Doble Cara>", "isDataActivated (AumentarValor)? : " + isDobleCaraActivated);
//
//                elemento.setPrecio(elemento.getPrecio() * 2);
//                elementos.set(i, elemento);
            Log.i("<Elementos>", "nombre elemento: " + elementos.get(i).getDato()
                    + " cantidad:" + elementos.get(i).getCantidad() +
                    "precio: " + elementos.get(i).getPrecio());
        }
        return elementos;
    }



    private void insertarElementsWorksRead(ArrayList<ElementsWorksRead> elementos){
        ContentValues newvalue = new ContentValues();
        dbadapter.open();
        newvalue.put("_Id_WorkRead", this.idworkread);

        Log.i("<Doble Cara>", "isDataActivated (insertarElemntsWrksRead)? : " + isDobleCaraActivated);
        if(isDobleCaraActivated)
            elementos = AumentarValorDobleCara(elementos);

        for (ElementsWorksRead elemento : elementos) {

            newvalue.put("Dato", elemento.getDato());
            newvalue.put("Icono", elemento.getIcono());
            newvalue.put("Precio", elemento.getPrecio());
            newvalue.put("Cantidad", elemento.getCantidad());

            dbadapter.Insertar("ElementsWorkRead", newvalue);

            Log.i(this.getLocalClassName(), "[[insertado de ElementsWorkRead]]");
            newvalue.remove("Dato");
            newvalue.remove("Icono");
            newvalue.remove("Precio");
            newvalue.remove("Cantidad");
        }
        dbadapter.close();
    }



    private void eliminarpreferencias() {
        SharedPreferences preferencias = getSharedPreferences("WorksRead", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferencias.edit();
        editor.remove("IdWorkRead");
        editor.remove("Existe");
        editor.apply();
    }



    //carga todos los componentes de vista asociados a una trabajo desde db
    private void Cargar_Archivos() {

        dbadapter.open();
        Cursor cursor = dbadapter.TrabajoporTitulo(trabajoElegido);
        int contador = 0;
        if (cursor.moveToFirst()) {
            do {
                ElementsWorks elemento = new ElementsWorks(
                        cursor.getInt(TRABAJO.Id),
                        cursor.getInt(TRABAJO.elemento),
                        cursor.getInt(TRABAJO.Trabajo),
                        "",
                        cursor.getInt(TRABAJO.posicion),
                        1,
                        ""
                );

                switch (elemento.getElemento()) {
                    case 1:
                        Anadir_EntradaNumerica(contador, elemento);
                        break;
                    case 2:
                        Anadir_EntradaNormal(R.layout.entradanormal, contador,elemento);
                        break;
                    case 4:
                        Anadir_Elegibles(contador, elemento);
                        break;
                    case 5:
                        Anadir_Despegables(contador, elemento);
                        break;
                    case 3:
                        Anadir_OpcionesUnicas(contador, elemento);
                        break;
                    case 7:
                        Anadir_Secuencia(contador, elemento);
                        break;
                }
//                i("[[ CargarArchivos() ]]",
//                        "elemento: " + elemento.getElemento() + "\tcontador: " + contador);
//                Log.e("HEYYYYYYYYYYYYYYYY1", "layoutElementos numero hijos: " + String.valueOf(layoutElementos.getChildCount()));
                contador++;

            } while (cursor.moveToNext());
        } else {
            cursor.close();
        }
        dbadapter.close();
    }




    private void Anadir_Secuencia(int i, ElementsWorks elementsWorks) {
        Anadir_EntradaNormal(R.layout.secuencia,i,elementsWorks);
    }



    private void Anadir_EntradaNumerica(Integer i, ElementsWorks Elemento) {
        Cursor cursorDatos;
        View inflatedLayout = getLayoutInflater().inflate(R.layout.entradanumerica, null, true);
//        final String inflatedLayout_info = "<context>: " + inflatedLayout.getContext() +
//                "<Raiz>: " + inflatedLayout.getRootView().toString() +
//                "<Tag>: " + inflatedLayout.getTag() +
//                "<Id>: " + inflatedLayout.getId();
//
//        Log.i("[add_entradaNum]", "[[inflated layoutElementos]]\n" + inflatedLayout_info);
        layoutElementos.addView(inflatedLayout);
        View vista = layoutElementos.getChildAt(i);


//        EditText editText = inflatedLayout.findViewById(R.id.editText);
//        editText.setText("ingresa algo aquí");
        EditText editText = (EditText) vista.findViewById(R.id.editText);
//        editText.setFilters(new InputFilter[]{new InputFilterMinMax("1", "10")});

        //obtener datos: dato, icono, precio.
        cursorDatos = dbadapter.obtenerdatos(
                String.valueOf(Elemento.getId()),
                String.valueOf(Elemento.getTrabajo())
        );
        cursorDatos.moveToFirst();

        //seteando <dato> en textView
        String nombreDato = cursorDatos.getString(DATOS.NombreDato);
        TextView texto = (TextView) vista.findViewById(R.id.textView);
        texto.setText(nombreDato);

        //seteando <icono> en textview oculto
        String icono = cursorDatos.getString(DATOS.Icono);
        texto = (TextView) vista.findViewById(R.id.rlenicono);
        texto.setText(icono);

        //seteando <precio> en textview oculto
        String precio = String.format(
                Locale.getDefault(),
                "%f",
                cursorDatos.getFloat(DATOS.Precio)
        );
        texto = (TextView) vista.findViewById(R.id.rlenprecio);
        texto.setText(precio);
    }



    private void Anadir_EntradaNormal(int idRecurso, Integer i,ElementsWorks elemento) {

        View inflatedLayout = getLayoutInflater().inflate(idRecurso, null, true);
        layoutElementos.addView(inflatedLayout);

        View vista_entradaNormal = layoutElementos.getChildAt(i);
        Cursor cursorDatos = dbadapter.obtenerdatos(
                String.valueOf( elemento.getId() ),
                String.valueOf( elemento.getTrabajo() )
        );




        cursorDatos.moveToFirst();

        //[Se addiere los datos a los compoenentes del layoutElementos]
        String nombreDato = cursorDatos.getString(DATOS.NombreDato);
        TextView textView_nombreDato = (TextView) vista_entradaNormal.findViewById(R.id.textView2);
        textView_nombreDato.setText(nombreDato);

        String icono = cursorDatos.getString(DATOS.Icono);
        TextView textView_icono = (TextView) vista_entradaNormal.findViewById(R.id.rlenmlicono);
        textView_icono.setText(icono);

        String precio = String.format(
                Locale.getDefault(),
                "%f",
                cursorDatos.getFloat(DATOS.Precio)
        );
        TextView textView_precio = (TextView) vista_entradaNormal.findViewById(R.id.rlenmlprecio);
        textView_precio.setText(precio);
    }



    private void Anadir_OpcionesUnicas(Integer i,ElementsWorks Elemento){
        Cursor cursordatos;
        View inflatedLayout = getLayoutInflater().inflate(R.layout.opcionesunicas, null, true);
        layoutElementos.addView(inflatedLayout);

        View LayoutOpcionesUnicas = layoutElementos.getChildAt(i);
        cursordatos = dbadapter.obtenerdatos(
                String.valueOf(Elemento.getId()),
                String.valueOf(Elemento.getTrabajo())
        );
        cursordatos.moveToFirst();

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        layoutParams.setMargins(0, 0, 0, 20);

        LayoutOpcionesUnicas.setLayoutParams(layoutParams);


        TextView textView_nombreDato = (TextView) LayoutOpcionesUnicas.findViewById(R.id.textView4);
        textView_nombreDato.setText(cursordatos.getString(DATOS.NombreDato));
        Integer contador = 1;

        while (!cursordatos.isLast()) {
            int idRadioButtonDato = 0;
            int idTextViewIcono = 0;
            int idTextViewPrecio = 0;


            cursordatos.moveToNext();
            switch (contador) {
                case 1:
                    idRadioButtonDato = R.id.radioButton;
                    idTextViewIcono = R.id.rlouicono;
                    idTextViewPrecio = R.id.rlouprecio;
                    break;
                case 2:
                    idRadioButtonDato = R.id.radioButton2;
                    idTextViewIcono = R.id.rlouicono2;
                    idTextViewPrecio =  R.id.rlouprecio2;
                    break;
                case 3:
                    idRadioButtonDato = R.id.radioButton3;
                    idTextViewIcono = R.id.rlouicono3;
                    idTextViewPrecio =  R.id.rlouprecio3;
                    break;
                case 4:
                    idRadioButtonDato = R.id.radioButton4;
                    idTextViewIcono = R.id.rlouicono4;
                    idTextViewPrecio =  R.id.rlouprecio4;
                    break;
                case 5:
                    idRadioButtonDato = R.id.radioButton5;
                    idTextViewIcono = R.id.rlouicono5;
                    idTextViewPrecio =  R.id.rlouprecio5;
                    break;
            }
            RadioButton radioButton = findViewById(idRadioButtonDato);
            setearRadioButton(
                    radioButton,
                    cursordatos,
                    LayoutOpcionesUnicas,
                    idTextViewIcono,
                    idTextViewPrecio
            );

            if(contador == 1)
                radioButton.setChecked(true);

            contador++;
        }
    }

    private void setearRadioButton(RadioButton radioButton, Cursor cursorDatos, View vista, int idIcono, int idPrecio) {

        radioButton.setText(cursorDatos.getString(DATOS.NombreDato));
        radioButton.setVisibility(View.VISIBLE);

        TextView textView_icono = (TextView) vista.findViewById(idIcono);
        textView_icono.setText(cursorDatos.getString(DATOS.Icono));

        textView_icono = (TextView) vista.findViewById(idPrecio);
        textView_icono.setText(String.format(
                Locale.getDefault(),
                "%f",
                cursorDatos.getFloat(DATOS.Precio))
        );
    }


    private int contador_elegibles = 0;


    private void Anadir_Elegibles(Integer i,ElementsWorks Elemento){
        contador_elegibles++;
        View inflatedLayout = getLayoutInflater().inflate(R.layout.elegibles, null, true);
        layoutElementos.addView(inflatedLayout);
        View LayoutElegibles = layoutElementos.getChildAt(i);

        Cursor cursorDatos = dbadapter.obtenerdatos(
                String.valueOf(Elemento.getId()),
                String.valueOf(Elemento.getTrabajo())
        );
        cursorDatos.moveToFirst();
        i("indices obtenidos", "indice: " + cursorDatos.getString(0) );

        String dato = cursorDatos.getString(DATOS.NombreDato);

        CheckBox checkBox = (CheckBox) LayoutElegibles.findViewById(R.id.elegiblescb);


        if(contador_elegibles == 1) {
            checkBox.setVisibility(View.INVISIBLE);
            TextView titulo = LayoutElegibles.findViewById(R.id.titulo);
            titulo.setText(dato);
            titulo.setVisibility(View.VISIBLE);

        } else  {
            checkBox.setText(dato);
        }





        TextView textView_icono = (TextView) LayoutElegibles.findViewById(R.id.rlelegiblesicono);
        textView_icono.setText(cursorDatos.getString(DATOS.Icono));

        TextView textView_precio = (TextView) LayoutElegibles.findViewById(R.id.rlelegiblesprecio);
        textView_precio.setText(String.format(
                Locale.getDefault(),
                "%f", cursorDatos.getFloat(DATOS.Precio) )
        );
    }





    private void Anadir_Despegables(Integer i,ElementsWorks Elemento){
        View inflatedLayout = getLayoutInflater().inflate(R.layout.desplegables, null, true);
        layoutElementos.addView(inflatedLayout);

        View layoutDesplegables = layoutElementos.getChildAt(i);
        Cursor cursorDatos = dbadapter.obtenerdatos(
                String.valueOf(Elemento.getId()),
                String.valueOf(Elemento.getTrabajo())
        );
        cursorDatos.moveToFirst();

        TextView textView_nombreDato = layoutDesplegables.findViewById(R.id.textView3);
        textView_nombreDato.setText(cursorDatos.getString(DATOS.NombreDato));

        Integer contador = 0;
        final Integer[] idIcono = {
                R.id.rldespegablesicono,
                R.id.rldespegablesicono2,
                R.id.rldespegablesicono3,
                R.id.rldespegablesicono4,
                R.id.rldespegablesicono5
        };
        final Integer[] idPrecio = {
                R.id.rldespegablesprecio,
                R.id.rldespegablesprecio2,
                R.id.rldespegablesprecio3,
                R.id.rldespegablesprecio4,
                R.id.rldespegablesprecio5
        };

        while (cursorDatos.moveToNext()) {
            TextView textView_icono = (TextView) layoutDesplegables.findViewById(idIcono[contador]);
            textView_icono.setText(cursorDatos.getString(DATOS.Icono));

            TextView textView_precio = (TextView) layoutDesplegables.findViewById(idPrecio[contador]);
            textView_precio.setText(String.format(
                    Locale.getDefault(),
                    "%f",
                    cursorDatos.getFloat(DATOS.Precio)));
            contador++;
        }
        Spinner spinner = findViewById(R.id.spinner);
        List<String> listaDatos = dbadapter.obtenerdatosspinner(
                String.valueOf(Elemento.getId()),
                String.valueOf(Elemento.getTrabajo())
        );
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, listaDatos);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(spinnerAdapter);
    }






/*    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            final Boolean vuelta[]=new Boolean[1];
            AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
            dialogo1.setTitle("IMPORTANTE");
            dialogo1.setMessage("¿Quieres salir?/nPerdera los datos de los trabajos");
            dialogo1.setCancelable(false);
            dialogo1.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dbadapter.open();
                    dbadapter.Eliminar("ElementsWorkRead", null, null);
                    dbadapter.Eliminar("WorksRead", null, null);
                    dbadapter.close();
                    Intent intent = new Intent(Layout_Trabajo.this, MainActivity.class);
                    startActivity(intent);
                    vuelta[0] = true;
                }
            });
            dialogo1.setNegativeButton("No", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    finish();
                    vuelta[0] = false;
                }
            });
            dialogo1.show();
            if (vuelta[0]){
                return true;
            }
            else {
                super.onBackPressed();
            }
        }
        return super.onKeyDown(keyCode,event);
    }*/

    /*@Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Really Exit?")
                .setMessage("Are you sure you want to exit?")
                .setNegativeButton(android.R.string.no, null)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface arg0, int arg1) {
                        Layout_Trabajo.super.onBackPressed();
                    }
                }).create().show();
    }*/

}
