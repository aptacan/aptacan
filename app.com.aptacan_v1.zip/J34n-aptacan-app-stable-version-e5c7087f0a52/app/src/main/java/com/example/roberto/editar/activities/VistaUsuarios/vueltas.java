package com.example.roberto.editar.activities.VistaUsuarios;
/*
 * La clase vueltaEnEuros se activa para realizar el manejo de sueltos (dinero a devolver despues de un pago)
 * en el programa. esta clase es usada por la clase pago para dicho proposito
 *
 * nota: - tod0s los valores de dinero son tratados en centavos en esta clase.
 */

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.Utiles;


public class vueltas extends AppCompatActivity implements ImageButton.OnClickListener{

    //en existenciaEnCaja se describen la cantidad de cada uno de los billetes/monedas que se tiene
    // {(cantidad de 1 cent), (cantidad de 2 cent), (cantidad de 5 cent) , ...... , (cantidad de 50 euros)}
    private Integer[] existenciaEnCaja = new Integer[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    private SharedPreferences preferencias;
    private Double vueltaEnEuros = 0.00;
    private Double totalEnCaja = 0.00;
    private int vueltaEnCents = 0;

    private static final String[] tagValoresMonederoXml = {
            "uncent",
            "doscent",
            "cincocent",
            "diezcent",
            "veintecent",
            "cincuentacent",
            "uneuro",
            "doseuros",
            "cincoeuros",
            "diezeuros",
            "veinteeuros",
            "cincunetaeuros"
    };

    private static final double[] valoresMonedasBilletes = { 0.01, 0.02, 0.05, 0.10, 0.20, 0.50, 1, 2, 5, 10, 20, 50 };




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferencias = getSharedPreferences("Monedero", MODE_PRIVATE);

        setContentView(R.layout.activity_vueltas);
        ImageButton monedaImg = findViewById(R.id.monedavuelta);
        monedaImg.setOnClickListener(this);

        //obtiene de los extras, la vueltaEnEuros a pagar
        Intent intent = getIntent();
        vueltaEnEuros = Utiles.redondearExacto(
                intent.getDoubleExtra("Vuelta", 0),
                2
        );

        vueltaEnCents = (int) (vueltaEnEuros * 100); //el vuelto en centavos
        cargarCaja();
//        getPosicionMonedaBillete();
    }



    @Override
    public void onClick(View v) {
        cargarImgMonedaBillete();
    }



    //Migra desde el monedero a el array de existenciaEnCaja las cantidades que existen de cada
    // Moneda/billete, tambien calcula cuanto en dinero existe en total existe(unidad: Euros).
    public void cargarCaja(){
//        String[] valores = new String[] {
//                "uncent",
//                "doscent",
//                "cincocent",
//                "diezcent",
//                "veintecent",
//                "cincuentacent",
//                "uneuro",
//                "doseuros",
//                "cincoeuros",
//                "diezeuros",
//                "veinteeuros",
//                "cincunetaeuros"
//        };
        final int size = tagValoresMonederoXml.length;

        for (int posicion = 0; posicion < size; posicion++) {
            int cantidadDeExistencia = preferencias.getInt(
                    tagValoresMonederoXml[posicion],
                    0
            );
            existenciaEnCaja[posicion] = cantidadDeExistencia;
            double valorEnEuros = valoresMonedasBilletes[posicion];

            totalEnCaja = totalEnCaja + (cantidadDeExistencia * valorEnEuros);
        }
        cargarImgMonedaBillete();
    }



    private void cargarImgMonedaBillete(){
        Integer[] monedasImgResId = {
                R.drawable.uncent, R.drawable.doscent, R.drawable.cincocent, R.drawable.diezcent,
                R.drawable.veintecent, R.drawable.cincuentacent, R.drawable.uneuro, R.drawable.doseuro,
                R.drawable.cincoeuro, R.drawable.diezeuro, R.drawable.veinteeuro, R.drawable.cincuentaeuro
        };
        int posicionMonedaBillete = getPosicionMonedaBillete();

        Log.i("\n[Vueltas]", "---El cambio: " + posicionMonedaBillete);

        if (posicionMonedaBillete > (-1)){
            ImageView imagenboton = findViewById(R.id.monedavuelta);
            Snackbar aviso = Snackbar.make(imagenboton, "Caja", Snackbar.LENGTH_SHORT);
            aviso.show();

            Glide.with(imagenboton.getContext())
                    .load(monedasImgResId[posicionMonedaBillete ])
                    .apply(new RequestOptions().fitCenter())
                    .into(imagenboton);

            DisminuirVuelta(posicionMonedaBillete);

//            /*SharedPreferences.Editor editor = preferencias.edit();
//            editor.putInt(valoresMoneda[num], preferencias.getInt(valoresMoneda[num], 0) - 1);
//            editor.apply();
//            vueltaEnEuros = vueltaEnEuros - obtenervalor(num);
//            vueltaEnCents = vueltaEnCents - (int) (obtenervalor(num) * 100);
//            if (vueltaEnCents==0){
//                Intent intento=new Intent(vueltas.this,Despedir.class);
//                startActivity(intento);
//            }*/

        } else if (posicionMonedaBillete == (-1)) {
            Intent intento = new Intent(vueltas.this, Despedir.class);
            startActivity(intento);
            finish();

        } else {
            Intent intento = new Intent(vueltas.this, SinCambio.class);
            startActivity(intento);
            finish();
        }
    }



    private void DisminuirVuelta(int posicion){
        SharedPreferences.Editor editor = preferencias.edit();
        editor.putInt(
                tagValoresMonederoXml[posicion],
                ( preferencias.getInt(tagValoresMonederoXml[posicion], 0) ) - 1
        );
        editor.apply();

        vueltaEnEuros = vueltaEnEuros - valoresMonedasBilletes[posicion];
        vueltaEnCents = vueltaEnCents - (int) (valoresMonedasBilletes[posicion] * 100);
        existenciaEnCaja[posicion]--;
        /*if (vueltaEnCents==0){
            Intent intento=new Intent(vueltas.this,Despedir.class);
            startActivity(intento);
        }*/
    }



    private int getPosicionMonedaBillete(){
        int posicion = 11;
        int posicionMonedaBillete = -2; //valor por defecto: "no hay cambio"
        //todos los valores de dinero en centavos
        Integer[] valoresEnCents = new Integer[]{ 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000 }; //valores de dinero en centavos

        Log.i("[vueltas]", "---vueltaEnEuros cent valor: " + vueltaEnEuros);

        if (vueltaEnCents != 0) {
            do{
                //si el suelto(en centavos) es mayor o igual a los [valores de dinero (en centavos)] y
                // se tiene en existencia dicho valor en existenciaEnCaja
                if (vueltaEnCents >= valoresEnCents[posicion] && existenciaEnCaja[posicion] > 0){
                    //salir=false;
                    posicionMonedaBillete = posicion;
                    return posicionMonedaBillete;
                }
                posicion--;
            }while ( posicion != (-1) );

        } else {
            posicionMonedaBillete = (-1); // retorna (-1) --> si el vuelto a devolver == 0
            return posicionMonedaBillete;
        }

        return posicionMonedaBillete; // retorna (-2) -- como valor por defecto si ninguna de las condiciones anteriores lo afecta
        // (osea cuando no hay existencia del valor requerido en existenciaEnCaja).
    }


}
