package com.example.roberto.editar.models;

import com.bumptech.glide.util.Util;
import com.example.roberto.editar.Utils.Utiles;

public class Rango {

    private int inicio;
    private int fin;
    private int cantidad;

    public Rango(int inicio, int fin, int cantidad) {
        this.inicio = inicio;
        this.fin = fin;
        this.cantidad = cantidad;
    }

    // ejemplo 4-5
    public Rango(String entrada) {
        setDatosRango(entrada);
    }

    public Rango() {

    }


    public int getInicio() {
        return inicio;
    }

    public void setInicio(int inicio) {
        this.inicio = inicio;
    }

    public int getFin() {
        return fin;
    }

    public void setFin(int fin) {
        this.fin = fin;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }


    private void setDatosRango(String entradaRango) {

        if(entradaRango.contains("-")) {
            inicio = Integer.parseInt(
                    entradaRango.substring(0, entradaRango.indexOf("-"))
            );
            fin = Integer.parseInt(
                    entradaRango.substring(entradaRango.lastIndexOf("-") + 1)
            );

            cantidad = Math.abs(fin - inicio) + 1;
        } else {

            inicio = 1;
            fin = Integer.parseInt(entradaRango);
            cantidad = Integer.parseInt(entradaRango);
        }
    }
}
