package com.example.roberto.editar.adapters;

public class Articulo {
    private int posicion;
    private String icono;

    public Articulo(int posicion, String icono) {
        this.posicion = posicion;
        this.icono = icono;
    }

    public int getPosicion() {
        return posicion;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }

    public String getIcono() {
        return icono;
    }

    public void setIcono(String icono) {
        this.icono = icono;
    }
}
