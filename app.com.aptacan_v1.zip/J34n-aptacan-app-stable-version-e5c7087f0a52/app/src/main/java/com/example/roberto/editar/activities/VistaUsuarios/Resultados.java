package com.example.roberto.editar.activities.VistaUsuarios;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.DbControl;
import com.example.roberto.editar.models.ElementsWorksRead;
import com.example.roberto.editar.models.WorksRead;

import java.io.File;

public class Resultados extends Activity implements ImageButton.OnClickListener{

    private DbControl dbadapter;
    private Integer cw=0;
    private Integer ce=0;
    private WorksRead[] worksread;
    private ElementsWorksRead[] elements;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultados);
        findViewById(R.id.imageverresultados1).setOnClickListener(this);
        dbadapter = new DbControl(this);
        cargarWorksRead();
        Toast.makeText(this, "la actividad resultado", Toast.LENGTH_SHORT).show();
        Log.i("[Resultados] ", "la actividad REsultados");
    }

    @Override
    public void onClick(View v) {
        if (ce<elements.length){
            cargarImagen(elements[ce].getIcono(),elements[ce].getDato());
            ce++;
        }else
            cw++;
        if(cw<worksread.length){
            ce=0;
            cargarImagen(worksread[cw].getIcono(),worksread[cw].getTitulo());
            rellenarElementos(worksread[cw].getId());
        }else{
            Intent intento=new Intent(Resultados.this,Pago.class);
            startActivity(intento);
            finish();
        }
    }

    private void cargarWorksRead(){
        dbadapter.open();
        Cursor cursor=dbadapter.ConsultaWorkReads(0,0);
        rellenarWorksRead(cursor);
        rellenarElementos(worksread[cw].getId());
        cargarImagen(worksread[cw].getIcono(),worksread[cw].getTitulo());
        dbadapter.close();
    }

    private void rellenarWorksRead(Cursor cursor) {
        int i = 0;
        worksread=new WorksRead[cursor.getCount()];
        if (cursor.moveToFirst()) {
            do {
                worksread[i] = new WorksRead(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getFloat(3)
                );
                i++;
            } while (cursor.moveToNext());
        } else {
            cursor.close();
        }

    }

    private void rellenarElementos(Integer id){
        dbadapter.open();
        Cursor cursor=dbadapter.ConsultaElementsWorkReads(id);
        elements=new ElementsWorksRead[cursor.getCount()];
        int i = 0;

        if (cursor.moveToFirst()) {
            do {
                elements[i]=new ElementsWorksRead(
                        cursor.getInt(0),
                        cursor.getInt(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getFloat(4),
                        cursor.getInt(5)
                );
                i++;
            } while (cursor.moveToNext());
        } else {
            cursor.close();
        }
    }

    private void cargarImagen(String icono,String texto){
        ImageView imagenboton=(ImageView) findViewById(R.id.imageverresultados1);
        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        File mypath = new File(directory,icono );
        Glide.with(imagenboton.getContext())
                .load(mypath.getPath())
                //.fitCenter()
                .into(imagenboton);
        TextView txt=(TextView) findViewById(R.id.datatext1);
        txt.setText(texto);
    }
}
