package com.example.roberto.editar.Utils;

import android.content.Context;
import android.os.AsyncTask;

import com.example.roberto.editar.Utils.DbControl;


public class ComprobarUsoImagen extends AsyncTask<String, Void, Boolean>{

    private Context context;
    private String imagen;

    public ComprobarUsoImagen(Context context,String imagen) {
        this.context = context;
        this.imagen = imagen;
    }

    // it was protected in the last
    public Boolean doInBackground(String... params) {
        Boolean eliminar = false;
        Integer coincidencias;

        DbControl bbdd = new DbControl(context);
        bbdd.open();
        coincidencias = bbdd.EstaImagen(imagen);
        bbdd.close();

        if (coincidencias != 0){
            eliminar = true;
        }
        return eliminar;
    }
}
