package com.example.roberto.editar.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.roberto.editar.activities.VistaAdministrador.DatoElemento;
import com.example.roberto.editar.activities.VistaAdministrador.GridViewElementImagenes;
import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.DbControl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class Elemento extends Activity implements View.OnClickListener, Spinner.OnItemSelectedListener, Spinner.OnItemClickListener {

    private DbControl dbadapter;
    private Boolean editar = false;
    private Intent intent;
    private Integer maxpos;
    private String trabajo;
    private String elementoant = null;
    private int datosini = 0;
    private int posini = 0;
    private String etid;
    private static int RESULT_LOAD_IMAGE = 1;

    private File directory;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elemento);
        dbadapter = new DbControl(this);
        intent = getIntent();
        if (intent.getExtras().getBoolean("nuevo")) {
            inicionuevo();
        } else {
            inicioeditar();
        }
        botonesclick();

        Button boton = (Button) findViewById(R.id.guardarelemento);
        boton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                dbadapter.open();

                TextView txtdatos = (TextView) findViewById(R.id.editText5);
                Integer datos = Integer.parseInt(txtdatos.getText().toString());
                TextView txtpos = (TextView) findViewById(R.id.textView18);
                Integer pos = Integer.parseInt(txtpos.getText().toString());
                Integer[] id = {R.id.dato1elemento, R.id.dato2elemento, R.id.dato3elemento, R.id.dato4elemento, R.id.dato5elemento, R.id.dato6elemento};

                if (editar) {
                    ContentValues newvalue = new ContentValues();
                    if (posini != pos) {
                        String actualizacion;
                        String argumento;
                        if (posini < pos) {
                            actualizacion = "-1";
                            argumento = "Posición<=" + pos + " and Posición>" + posini;
                        } else {
                            actualizacion = "+1";
                            argumento = "Posición>=" + pos + " and Posición<" + posini;
                        }
                        //Actualizar la posición del resto de elementos que se ven influidos
                        actualizar_pos_other_elements(argumento, actualizacion);
                        //Actualizar el elemento y la posición del elemento de la vista
                        actualizar_elemento(pos.toString());
                    } else {
                        //Actualizamos el elemento, sólo cambia el icono.
                        actualizar_elemento(pos.toString());
                    }
                    if (datosini != datos) {
                        if (datosini < datos) {
                            //Actualizar los datos existentes
                            String dato;
                            String precio;
                            String icono;
                            String[] argumento = new String[1];
                            Integer[] ids = dbadapter.Idsdatos(etid, trabajo);
                            Integer[] idprize = {R.id.dato1precio, R.id.dato2precio, R.id.dato3precio, R.id.dato4precio, R.id.dato5precio, R.id.dato6precio};
                            Integer[] idicono = {R.id.txt1icono, R.id.txt2icono, R.id.txt3icono, R.id.txt4icono, R.id.txt5icono, R.id.txt6icono};
                            newvalue.clear();
                            for (int i = 0; i < datosini; i++) {
                                TextView txt = (TextView) findViewById(id[i]);
                                dato = txt.getText().toString();
                                txt = (TextView) findViewById(idprize[i]);
                                precio = txt.getText().toString();
                                txt = (TextView) findViewById(idicono[i]);
                                icono = txt.getText().toString();

                                argumento[0] = ids[i].toString();
                                newvalue.put("Dato", dato);
                                newvalue.put("Icono", icono);
                                newvalue.put("Precio", precio);
                                dbadapter.Actualizar("Datos", newvalue, "_Id=?", argumento);
                                newvalue.remove("Dato");
                                newvalue.remove("Icono");
                                newvalue.remove("Precio");
                            }
                            //Insertar los datos nuevos
                            newvalue.clear();
                            newvalue.put("Elemento", etid);
                            newvalue.put("Trabajo", trabajo);
                            for (int i = datosini; i < datos; i++) {
                                TextView txt = (TextView) findViewById(id[i]);
                                dato = txt.getText().toString();
                                txt = (TextView) findViewById(idprize[i]);
                                precio = txt.getText().toString();
                                txt = (TextView) findViewById(idicono[i]);
                                icono = txt.getText().toString();
                                newvalue.put("Dato", dato);
                                newvalue.put("Icono", icono);
                                newvalue.put("Precio", precio);
                                dbadapter.Insertar("Datos", newvalue);
                                newvalue.remove("Dato");
                                newvalue.remove("Icono");
                                newvalue.remove("Precio");
                            }
                        } else {
                            //Eliminar los datos que ya no existen
                            dbadapter.EliminarDatos(datosini - datos, etid, trabajo);
                            //Actualizar los datos que quedan
                            String dato;
                            String precio;
                            String icono;
                            String[] argumento = new String[1];
                            Integer[] ids = dbadapter.Idsdatos(etid, trabajo);
                            Integer[] idprize = {R.id.dato1precio, R.id.dato2precio, R.id.dato3precio, R.id.dato4precio, R.id.dato5precio, R.id.dato6precio};
                            Integer[] idicono = {R.id.txt1icono, R.id.txt2icono, R.id.txt3icono, R.id.txt4icono, R.id.txt5icono, R.id.txt6icono};
                            int i;
                            newvalue.clear();
                            for (i = 0; i < datos; i++) {
                                TextView txt = (TextView) findViewById(id[i]);
                                dato = txt.getText().toString();
                                txt = (TextView) findViewById(idprize[i]);
                                precio = txt.getText().toString();
                                txt = (TextView) findViewById(idicono[i]);
                                icono = txt.getText().toString();
                                argumento[0] = ids[i].toString();
                                newvalue.put("Dato", dato);
                                newvalue.put("Icono", icono);
                                newvalue.put("Precio", precio);
                                dbadapter.Actualizar("Datos", newvalue, "_Id=?", argumento);
                                newvalue.remove("Dato");
                                newvalue.remove("Icono");
                                newvalue.remove("Precio");
                            }
                        }
                    } else {
                        //Actualizar los datos
                        String dato;
                        String precio;
                        String icono;
                        String[] argumento = new String[1];
                        Integer[] ids = dbadapter.Idsdatos(etid, trabajo);
                        Integer[] idprize = {R.id.dato1precio, R.id.dato2precio, R.id.dato3precio, R.id.dato4precio, R.id.dato5precio, R.id.dato6precio};
                        Integer[] idicono = {R.id.txt1icono, R.id.txt2icono, R.id.txt3icono, R.id.txt4icono, R.id.txt5icono, R.id.txt6icono};
                        int i;
                        newvalue.clear();
                        for (i = 0; i < datos; i++) {
                            TextView txt = (TextView) findViewById(id[i]);
                            dato = txt.getText().toString();
                            txt = (TextView) findViewById(idprize[i]);
                            precio = txt.getText().toString();
                            txt = (TextView) findViewById(idicono[i]);
                            icono = txt.getText().toString();
                            argumento[0] = ids[i].toString();
                            newvalue.put("Dato", dato);
                            newvalue.put("Icono", icono);
                            newvalue.put("Precio", precio);
                            dbadapter.Actualizar("Datos", newvalue, "_Id=?", argumento);
                            newvalue.remove("Dato");
                            newvalue.remove("Icono");
                            newvalue.remove("Precio");
                        }
                    }

                } else {
                    //Insertar elemento
                    insertar_elemento();
                    //Insertar los datos
                    String dato;
                    String precio;
                    String icono;
                    Integer[] idprize = {R.id.dato1precio, R.id.dato2precio, R.id.dato3precio, R.id.dato4precio, R.id.dato5precio, R.id.dato6precio};
                    Integer[] idicono = {R.id.txt1icono, R.id.txt2icono, R.id.txt3icono, R.id.txt4icono, R.id.txt5icono, R.id.txt6icono};
                    ContentValues newvalue = new ContentValues();
                    Integer elemento;
                    elemento = dbadapter.maxelemento(trabajo);
                    newvalue.put("Elemento", elemento);
                    newvalue.put("Trabajo", trabajo);
                    for (int i = 0; i < datos; i++) {
                        TextView txt = (TextView) findViewById(id[i]);
                        dato = txt.getText().toString();
                        txt = (TextView) findViewById(idprize[i]);
                        precio = txt.getText().toString();
                        txt = (TextView) findViewById(idicono[i]);
                        icono = txt.getText().toString();
                        newvalue.put("Dato", dato);
                        newvalue.put("Icono", icono);
                        newvalue.put("Precio", precio);
                        dbadapter.Insertar("Datos", newvalue);
                        newvalue.remove("Dato");
                        newvalue.remove("Icono");
                        newvalue.remove("Precio");
                    }
                }

                /*Intent intento = new Intent(Elemento.this, ListaDeElementosTrabajos.class);
                intento.putExtra("Trabajo", trabajo);
                intento.putExtra("titulo", dbadapter.trabajo(trabajo));
                startActivity(intento);*/
                dbadapter.close();
                finish();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_elemento, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            finish();//return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private int obtenerdato(String nombre) {
        Integer pos = 0;
        switch (nombre) {
            case "Entrada_Númerica":
                pos = 0;
                break;
            case "Entrada_Normal":
                pos = 1;
                break;
            case "Opciones":
                pos = 2;
                break;
            case "Elegibles":
                pos = 3;
                break;
            case "Desplegables":
                pos = 4;
                break;
            case "Entrada_Botón":
                pos = 5;
                break;
            case "Secuencia":
                pos = 6;
                break;
        }
        return pos;
    }

    private void inicioeditar() {
        editar = true;
        trabajo = intent.getExtras().getString("trabajo");
        dbadapter.open();
        maxpos = dbadapter.maxposicion(trabajo);
        dbadapter.close();
        String datos = intent.getExtras().getString("datos").substring(10);
        TextView txtdatos = (TextView) findViewById(R.id.editText5);
        txtdatos.setText(datos);
        datosini = Integer.parseInt(datos);
        String posicion = intent.getExtras().getString("posicion").substring(10);
        TextView txtposicion = (TextView) findViewById(R.id.textView18);
        txtposicion.setText(posicion);
        posini = Integer.parseInt(posicion);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setSelection(obtenerdato(intent.getExtras().getString("nombre")));
        String nombre = spinner.getSelectedItem().toString();
        if (nombre.equals("Opciones") || nombre.equals("Desplegables")) {
            botonesdatos(Integer.parseInt(datos));
        } else {
            deshabilitarboton(R.id.button7);
            deshabilitarboton(R.id.button8);
        }
        botonespos(Integer.parseInt(posicion));
        textdatos(Integer.parseInt(datos));
        etid = intent.getExtras().getString("etid");
        rellenardatos(etid, trabajo);
    }

    private void inicionuevo() {
        trabajo = intent.getExtras().getString("trabajo");
        String datos = "1";
        dbadapter.open();
        maxpos = dbadapter.maxposicion(trabajo);
        dbadapter.close();
        maxpos++;

        TextView txtdatos = (TextView) findViewById(R.id.editText5);
        txtdatos.setText(datos);

        TextView txtposicion = (TextView) findViewById(R.id.textView18);
        txtposicion.setText(maxpos.toString());

        deshabilitarboton(R.id.button7);
        deshabilitarboton(R.id.button8);

        botonespos(maxpos);
        textdatos(Integer.parseInt(datos));
    }

    private void botonesdatos(int datos) {
        deshabilitarboton(R.id.button7);
        deshabilitarboton(R.id.button8);
        if (datos > 3 && datos < 6) {
            habilitarboton(R.id.button7);
            habilitarboton(R.id.button8);
        } else if (datos > 3) {
            habilitarboton(R.id.button7);
        } else if (datos < 6) {
            habilitarboton(R.id.button8);
        }
    }

    private void botonespos(int pos) {
        deshabilitarboton(R.id.button10);
        deshabilitarboton(R.id.button11);
        if (pos > 1 && pos < maxpos) {
            habilitarboton(R.id.button10);
            habilitarboton(R.id.button11);
        } else if (pos > 1) {
            habilitarboton(R.id.button10);
        } else if (pos < maxpos) {
            habilitarboton(R.id.button11);
        }
    }

    private void textdatos(int datos) {
        deshabilitartxt(R.id.linearLayout4);
        deshabilitartxt(R.id.linearLayout5);
        deshabilitartxt(R.id.linearLayout6);
        deshabilitartxt(R.id.linearLayout7);
        deshabilitartxt(R.id.linearLayout8);
        deshabilitartxt(R.id.linearLayout9);
        switch (datos) {
            case 1: {
                habilitartxt(R.id.linearLayout4);
                break;
            }
            case 2: {
                habilitartxt(R.id.linearLayout4);
                habilitartxt(R.id.linearLayout5);
                break;
            }
            case 3: {
                habilitartxt(R.id.linearLayout4);
                habilitartxt(R.id.linearLayout5);
                habilitartxt(R.id.linearLayout6);
                break;
            }
            case 4: {
                habilitartxt(R.id.linearLayout4);
                habilitartxt(R.id.linearLayout5);
                habilitartxt(R.id.linearLayout6);
                habilitartxt(R.id.linearLayout7);
                break;
            }
            case 5: {
                habilitartxt(R.id.linearLayout4);
                habilitartxt(R.id.linearLayout5);
                habilitartxt(R.id.linearLayout6);
                habilitartxt(R.id.linearLayout7);
                habilitartxt(R.id.linearLayout8);
                break;
            }
            case 6: {
                habilitartxt(R.id.linearLayout4);
                habilitartxt(R.id.linearLayout5);
                habilitartxt(R.id.linearLayout6);
                habilitartxt(R.id.linearLayout7);
                habilitartxt(R.id.linearLayout8);
                habilitartxt(R.id.linearLayout9);
                break;
            }
        }
    }

    private void habilitarboton(int num) {
        Button boton = (Button) findViewById(num);
        boton.setEnabled(true);
    }

    private void habilitartxt(int num) {
        LinearLayout layoutdato = (LinearLayout) findViewById(num);
        layoutdato.setVisibility(View.VISIBLE);
    }

    private void deshabilitarboton(int num) {
        Button boton = (Button) findViewById(num);
        boton.setEnabled(false);
    }

    private void deshabilitartxt(int num) {
        LinearLayout layoutdato = (LinearLayout) findViewById(num);
        layoutdato.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        View view = (View) v.getParent();
        switch (v.getId()) {
            case R.id.button7: {
                TextView txtdatos = (TextView) view.findViewById(R.id.editText5);
                Integer datos = Integer.parseInt(txtdatos.getText().toString());
                datos--;
                txtdatos.setText(datos.toString());
                botonesdatos(datos);
                textdatos(datos);
                break;
            }
            case R.id.button8: {
                TextView txtdatos = (TextView) view.findViewById(R.id.editText5);
                Integer datos = Integer.parseInt(txtdatos.getText().toString());
                datos++;
                txtdatos.setText(datos.toString());
                botonesdatos(datos);
                textdatos(datos);
                break;
            }
            case R.id.button10: {
                TextView txtpos = (TextView) view.findViewById(R.id.textView18);
                Integer pos = Integer.parseInt(txtpos.getText().toString());
                pos--;
                txtpos.setText(pos.toString());
                botonespos(pos);
                break;
            }
            case R.id.button11: {
                TextView txtpos = (TextView) view.findViewById(R.id.textView18);
                Integer pos = Integer.parseInt(txtpos.getText().toString());
                pos++;
                txtpos.setText(pos.toString());
                botonespos(pos);
                break;
            }
            case R.id.imageView: {
                Intent i = new Intent(this, GridViewElementImagenes.class);
                startActivityForResult(i, RESULT_LOAD_IMAGE); ///-------------------------------------------------------------------------
                break;
            }
            case R.id.dato1: {
                Integer numero = 1;
                pasardatos_elemento(numero);
                break;
            }
            case R.id.dato2: {
                Integer numero = 2;
                pasardatos_elemento(numero);
                break;
            }
            case R.id.dato3: {
                Integer numero = 3;
                pasardatos_elemento(numero);
                break;
            }
            case R.id.dato4: {
                Integer numero = 4;
                pasardatos_elemento(numero);
                break;
            }
            case R.id.dato5: {
                Integer numero = 5;
                pasardatos_elemento(numero);
                break;
            }
            case R.id.dato6: {
                Integer numero = 6;
                pasardatos_elemento(numero);
                break;
            }
            default: {
                break;
            }
        }

    }

    private void botonesclick() {
        (findViewById(R.id.button7)).setOnClickListener(this);
        (findViewById(R.id.button8)).setOnClickListener(this);
        (findViewById(R.id.button10)).setOnClickListener(this);
        (findViewById(R.id.button11)).setOnClickListener(this);
        (findViewById(R.id.dato1)).setOnClickListener(this);
        (findViewById(R.id.dato2)).setOnClickListener(this);
        (findViewById(R.id.dato3)).setOnClickListener(this);
        (findViewById(R.id.dato4)).setOnClickListener(this);
        (findViewById(R.id.dato5)).setOnClickListener(this);
        (findViewById(R.id.dato6)).setOnClickListener(this);
        Spinner spinner = (Spinner) (findViewById(R.id.spinner));
        spinner.setOnItemSelectedListener(this);

    }

    private void rellenardatos(String et, String trabajo) {
        dbadapter.open();
        Cursor mcursor = dbadapter.obtenerdatos(et, trabajo);
        dbadapter.close();
        Integer[] id = {R.id.dato1elemento, R.id.dato2elemento, R.id.dato3elemento, R.id.dato4elemento, R.id.dato5elemento, R.id.dato6elemento};
        Integer[] idimage = {R.id.imageView4, R.id.imageView5, R.id.imageView6, R.id.imageView7, R.id.imageView8, R.id.imageView9};
        Integer[] idprize = {R.id.dato1precio, R.id.dato2precio, R.id.dato3precio, R.id.dato4precio, R.id.dato5precio, R.id.dato6precio};
        Integer[] idicono = {R.id.txt1icono, R.id.txt2icono, R.id.txt3icono, R.id.txt4icono, R.id.txt5icono, R.id.txt6icono};
        Integer i = 0;
        Spinner spinner = (Spinner) (findViewById(R.id.spinner));
        int pos =spinner.getSelectedItemPosition()+1;
        do {
            //Llenamos el textview del dato
            TextView txt = (TextView) findViewById(id[i]);
            txt.setText(mcursor.getString(0));

            //ocultar la imagen en la configuracion del elemento
            if ((pos==3 || pos==5) && id[i] == R.id.dato1elemento) {
                ImageView image = (ImageView) findViewById(idimage[i]);
                image.setVisibility(View.GONE);
                TextView txticono = (TextView) findViewById(idicono[i]);
                txticono.setText(mcursor.getString(1));
            }else{
                //Llenamos el imageview del dato
                txt = (TextView) findViewById(idicono[i]);
                txt.setText(mcursor.getString(1));
                ImageView image = (ImageView) findViewById(idimage[i]);
                ContextWrapper cw = new ContextWrapper(getApplicationContext());
                File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
                File mypath = new File(directory, mcursor.getString(1));
                Glide.with(image.getContext())
                        .load(mypath.getPath())
                        .apply(
                                new RequestOptions().override(100, 100)
                                        .error(R.drawable.nocamera) )
                        .into(image);
                //Llenamos el textview del icono
                TextView txticono = (TextView) findViewById(idicono[i]);
                txticono.setText(mcursor.getString(1));
            }
            //Llenamos el precio del dato
            TextView txtprize = (TextView) findViewById(idprize[i]);
            Float precio = mcursor.getFloat(2);
            txtprize.setText(precio.toString());

            i++;
        } while (mcursor.moveToNext());

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        final String elemento = parent.getItemAtPosition(position).toString();
        TextView txtdatos = (TextView) findViewById(R.id.editText5);
        Integer datos = Integer.parseInt(txtdatos.getText().toString());
        if (elementoant == null) {
            elementoant = elemento;
        }
//        if ((elemento.equals("Opciones") || elemento.equals("Desplegables") || elemento.equals("Elegibles"))) {

        //mostrar 3 elementos para setear en los elementos multiples, (osea solo para elementos multiples)
        if ((elemento.equals("Opciones") || elemento.equals("Desplegables"))) {
            if (datos < 3) {
                String Datos = "3";
                txtdatos.setText(Datos);
                botonesdatos(Integer.parseInt(Datos));
            }

        } else if (datos > 1) {
            AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
            dialogo1.setTitle("IMPORTANTE");
            dialogo1.setMessage(" Vas a perder datos con está acción.¿ Estas Seguro ?");
            dialogo1.setCancelable(false);
            dialogo1.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    elementoant = elemento;
                    String Datos = "1";
                    deshabilitarboton(R.id.button7);
                    deshabilitarboton(R.id.button8);
                    TextView txtdatos = (TextView) findViewById(R.id.editText5);
                    txtdatos.setText(Datos);
                    textdatos(Integer.parseInt(Datos));

                }
            });
            dialogo1.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    Spinner spinner = (Spinner) findViewById(R.id.spinner);
                    spinner.setSelection(obtenerdato(elementoant));
                    dialogo1.dismiss();
                }
            });
            dialogo1.show();

        } else {
            elementoant = elemento;
            deshabilitarboton(R.id.button7);
            deshabilitarboton(R.id.button8);
            txtdatos.setText("1");
        }
        datos = Integer.parseInt(txtdatos.getText().toString());
        textdatos(datos);
        //Mostramos la selección actual del Spinner
        Toast.makeText(this, "Selección actual: " + elemento, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        String elemento = spinner.getSelectedItem().toString();
        TextView txtdatos = (TextView) findViewById(R.id.editText5);
        Integer datos = Integer.parseInt(txtdatos.getText().toString());
        if ((elemento.equals("Opciones") || elemento.equals("Desplegables"))) {
            botonesdatos(datos);
        } else if (datos > 1) {
            deshabilitarboton(R.id.button7);
            deshabilitarboton(R.id.button8);
        }
    }

    private void actualizar_elemento(String pos) {
        ContentValues newvalue = new ContentValues();
        newvalue.put("Posición", pos.toString());
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        String nombre = spinner.getSelectedItem().toString();
        Integer elemento = obtenerdato(nombre);
        newvalue.put("Elemento", elemento + 1);
        String[] argumentos = new String[]{etid, trabajo};
        dbadapter.Actualizar("Elementos_Trabajos", newvalue, "_Id=? and Trabajo=?", argumentos);
    }

    private void actualizar_pos_other_elements(String argumento, String actualizacion) {
        dbadapter.Actualizarpos(etid, trabajo, argumento, actualizacion);
    }

    private void insertar_elemento() {
        //Obtenemos los datos del elemento
        ContentValues newvalue = new ContentValues();
        //Tipo de elemento
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        String nombre = spinner.getSelectedItem().toString();
        Integer elemento = obtenerdato(nombre);
        //La posición del elemento
        TextView txtposicion = (TextView) findViewById(R.id.textView18);
        String posicion = txtposicion.getText().toString();

        //Si la posición es distinta de la posición máxima se actualiza la posición de los demás elementos involucrados
        if (maxpos != Integer.parseInt(posicion)) {
            String actualizacion = "+1";
            String argumento = "Posición>=" + posicion;
            elemento++;
            dbadapter.Actualizarpos("0", trabajo, argumento, actualizacion);
        }

        //Ponemos los valores en los pares del elemento
        newvalue.put("Elemento", elemento + 1);
        newvalue.put("Trabajo", trabajo);
        newvalue.put("Posición", posicion);
        dbadapter.Insertar("Elementos_Trabajos", newvalue);

    }

    private void pasardatos_elemento(Integer numero) {
        Integer[] id = {R.id.dato1elemento, R.id.dato2elemento, R.id.dato3elemento, R.id.dato4elemento, R.id.dato5elemento, R.id.dato6elemento};
        Integer[] idprize = {R.id.dato1precio, R.id.dato2precio, R.id.dato3precio, R.id.dato4precio, R.id.dato5precio, R.id.dato6precio};
        Integer[] idicono = {R.id.txt1icono, R.id.txt2icono, R.id.txt3icono, R.id.txt4icono, R.id.txt5icono, R.id.txt6icono};
        //Obtenemos el tipo de elemento
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        String nombre = spinner.getSelectedItem().toString();
        Integer elemento = obtenerdato(nombre);
        //Obtenemos el dato
        TextView txt = (TextView) findViewById(id[numero - 1]);
        String dato = txt.getText().toString();
        //Obtenemos el precio
        txt = (TextView) findViewById(idprize[numero - 1]);
        String precio = txt.getText().toString();
        //Obtenemos el icono
        txt = (TextView) findViewById(idicono[numero - 1]);
        String icono = txt.getText().toString();

        //Creamos un intent con los datos a pasar a la activity.
        Intent i = new Intent(this, DatoElemento.class);
        i.putExtra("numero", String.format("%d", numero));
        i.putExtra("elemento", elemento + 1);
        i.putExtra("dato", dato);
        i.putExtra("icono", icono);
        i.putExtra("precio", precio);

        startActivityForResult(i, RESULT_LOAD_IMAGE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Integer[] id = {R.id.dato1elemento, R.id.dato2elemento, R.id.dato3elemento, R.id.dato4elemento, R.id.dato5elemento, R.id.dato6elemento};
        Integer[] idimage = {R.id.imageView4, R.id.imageView5, R.id.imageView6, R.id.imageView7, R.id.imageView8, R.id.imageView9};
        Integer[] idprize = {R.id.dato1precio, R.id.dato2precio, R.id.dato3precio, R.id.dato4precio, R.id.dato5precio, R.id.dato6precio};
        Integer[] idicono = {R.id.txt1icono, R.id.txt2icono, R.id.txt3icono, R.id.txt4icono, R.id.txt5icono, R.id.txt6icono};
        // check if the request code is same as what is passed  here it is 2
        if (requestCode == RESULT_LOAD_IMAGE && null != data) {
            //Recogemos los datos de la activity DatoElemento
            String dato = data.getStringExtra("dato");
            String icono = data.getStringExtra("icono");
            Log.i("<Icono>", "elemento: " + icono);
            String precio = data.getStringExtra("precio");
            String numero = data.getStringExtra("numero");

            //Escribir el dato en su textView
            TextView txt = (TextView) findViewById(id[Integer.parseInt(numero) - 1]);
            txt.setText(dato);
            //Escribir el precio en su textView
            txt = (TextView) findViewById(idprize[Integer.parseInt(numero) - 1]);
            txt.setText(precio);
            //Escribir el icono en su textView y cargar la imagen en el ImageView
            txt = (TextView) findViewById(idicono[Integer.parseInt(numero) - 1]);
            txt.setText(icono);

            ImageView image = (ImageView) findViewById(idimage[Integer.parseInt(numero) - 1]);
            ContextWrapper cw = new ContextWrapper(getApplicationContext());
            directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
            File mypath = new File(directory, icono);

            Log.i("<Icono>", "elementodir" + mypath.getPath());

            Glide.with(image.getContext())
                    .load(mypath.getPath())
                    .apply(
                    new RequestOptions().override(100, 100)
                            .error(R.drawable.nocamera) )
                    .into(image);
        }
    }































}
