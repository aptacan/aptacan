package com.example.roberto.editar.activities.VistaUsuarios;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SnapHelper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.roberto.editar.adapters.ArticuloRecyclerAdapter;
import com.example.roberto.editar.models.ElementsWorksRead;
import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.DbControl;
import com.example.roberto.editar.models.WorksRead;
import com.google.android.gms.common.internal.AccountType;

import java.io.File;

/**
 * La siguiente clase es usada para mostrar los requerimientos del trabajo, a realizar por parte del alumno,
 * por medio de una de pantallazos seguidos, de la misma actividad. En este se muestra la imagen y el titulo
 * de la opcion elegida. por ejemplo. Fotocopiar,
 * 1re (Fotocopiar: [imagen_fotocopiar], [titulo])
 * 2da ([imagen_del_6], [numero: 6])
 * 3re ([imagen_Blanco_y_negro], ["blanco y negro"])
 * 4ta ([imagen_que_representa_a4], ["A4 (210x297)"])
 * Luego al final llama al siguiente activity
 */

public class ver_resultados extends Activity implements ImageButton.OnClickListener{

    private DbControl dbadapter;
    private Integer contadorWorks = 0;
    private int contadorElementos = 0, numcom=0,posciclo=0;
    private WorksRead[] worksread;
    private ElementsWorksRead[] elementosDelTrabajo;
    private Integer idini;
    private Integer idfin;
    private int contador = 0;

    private ImageButton imagenIndicaciones;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_resultados);

        imagenIndicaciones = findViewById(R.id.imageverresultados);
        imagenIndicaciones.setOnClickListener(this);

        dbadapter = new DbControl(this);
        dbadapter.open();
        cargarWorksRead();

        final String mensaje = "\nContador de elementos: " + this.contadorElementos +
                "\nContador de trabajos: " +  this.contadorWorks;
        Log.i("[ver_resultados]: ", mensaje);
    }

    @Override
    public void onClick(View v) {
        /*
         * Cada elemento puede tener varios componentes, y cada componente puede ser un ciclo
         */
        if (contadorElementos < elementosDelTrabajo.length) {
//            Log.i("[Ver_resultados]: ", "contadorElementos: " + contadorElementos + "\telementosLength: " + elementosDelTrabajo.length);

            ElementsWorksRead elemento = elementosDelTrabajo[contadorElementos];
//            Log.i("\n[datos_elementos]: ", "titulo elemento: " + elemento.getDato());

            if (elemento.getId() == 0) {
                numcom = 0;
                posciclo = 0;
                cargarImagen(elemento.getIcono(), elemento.getDato());
                contadorElementos++;
                Log.w("[ELEMENTO_ID_0]: ", "El Id es 0");

            } else {
                String eltotal = elemento.getDato();


//                Log.i("[ultimo valor]", "elemento.getDato() ultimo: " + eltotal + "\n\n");

                String[] componentes = eltotal.split(",");

                int cantidadDeComponentes = componentes.length;
                String componenteActual = componentes[numcom];
                String[] lims = componenteActual.split("-");


                //testing code
                for (String limites :
                        lims) {
//                    Log.i("[Componentes]: ", "limites -> " + limites);
                }


                for (String componente :
                        componentes) {
//                    Log.i("[Componentes]: ", "componentes -> " + componente);
                }
                //final testing code

                int posactual = Integer.parseInt("0") + posciclo;



                cargarImagen(elemento.getIcono(), elemento.getDato());
                if(contadorElementos == 0)
                    mostrarListaArticulos();


                Log.i("testeando: ", "escribiendo imagen icono: " + elemento.getIcono());

                if(lims.length==1 || posactual==Integer.parseInt(lims[1])) {
                    numcom++;
                    posciclo=0;
                } else {
                    posciclo++;
                }

                if (numcom >= cantidadDeComponentes - 1) {
                    contadorElementos++;
                    numcom=0;
                    posciclo=0;
                }


            }

        } else {
            contadorWorks++;

            if (contadorWorks < worksread.length) {
                contadorElementos = 0;
                WorksRead worksRead = worksread[contadorWorks];

                cargarImagen(worksRead.getIcono(), worksRead.getTitulo());
                rellenarElementos(worksRead.getId());
            } else {
                Intent intent = new Intent(ver_resultados.this, Pagar.class);
                intent.putExtra("idini",idini);
                intent.putExtra("idfin",idfin);
                startActivity(intent);
                dbadapter.close();
                finish();
            }
        }

    }



    private void cargarWorksRead(){
        SharedPreferences preferencias = getSharedPreferences("WorksRead",MODE_PRIVATE);
        idini = preferencias.getInt("idini",0);
        SharedPreferences.Editor modif=preferencias.edit();
        modif.remove("idini");
        modif.apply();
        idfin = preferencias.getInt("idfin",0);

        Cursor cursor = dbadapter.ConsultaWorkReads(idini,idfin);
        rellenarWorksRead(cursor);
        rellenarElementos(worksread[contadorWorks].getId());
        cargarImagen(
                worksread[contadorWorks].getIcono(),
                worksread[contadorWorks].getTitulo()
        );
    }



    private void mostrarListaArticulos() {
        imagenIndicaciones.setVisibility(View.GONE);

        RecyclerView articulosRecycledView = findViewById(R.id.articulos_recyclerview);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);

        articulosRecycledView.setLayoutManager(linearLayoutManager);

        View.OnClickListener listenerItemClickFromActivity = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    imagenIndicaciones.setVisibility(View.VISIBLE);
                    imagenIndicaciones.callOnClick();
                Log.i("recycler", "bueno esta funcionando");
            }
        };

        final ArticuloRecyclerAdapter articuloRecyclerAdapter =
                new ArticuloRecyclerAdapter(
                        elementosDelTrabajo,
                        4,
                        this,
                        listenerItemClickFromActivity
                );

        articulosRecycledView.setAdapter(articuloRecyclerAdapter);
    }



    private void rellenarWorksRead(Cursor cursor){
        int i = 0;
        worksread = new WorksRead[cursor.getCount()];

        if (cursor.moveToFirst()) {
            do {
                worksread[i] = new WorksRead(
                        cursor.getInt(0),       //id
                        cursor.getString(1),    //titulo
                        cursor.getString(2),    //icono
                        cursor.getFloat(3)      //precio
                );
                i++;
            } while (cursor.moveToNext());
        } else {
            cursor.close();
        }

    }


    private void rellenarElementos(Integer id){
        dbadapter.open();
        Cursor cursor=dbadapter.ConsultaElementsWorkReads(id);
        elementosDelTrabajo =new ElementsWorksRead[cursor.getCount()];
        int i = 0;

        if (cursor.moveToFirst()) {
            do {
                elementosDelTrabajo[i] = new ElementsWorksRead(
                        cursor.getInt(0),       //id
                        cursor.getInt(1),       //id_workread
                        cursor.getString(2),    //dato
                        cursor.getString(3),    //icono
                        cursor.getFloat(4),     //precio
                        cursor.getInt(5)        //cantidad
                );
                i++;
            } while (cursor.moveToNext());
        } else {
            cursor.close();
        }
    }


    private void cargarImagen(String icono,String texto){
        ImageButton imagenboton = findViewById(R.id.imageverresultados);
        ContextWrapper cw = new ContextWrapper(getApplicationContext());



        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        File archivoImagen = new File(directory,icono );

        if(archivoImagen.exists()) {
            Glide.with(imagenboton.getContext())
                    .load(archivoImagen.getPath())
                    .apply(new RequestOptions().fitCenter())
                    .into(imagenboton);
        }
        TextView txt = findViewById(R.id.datatext);
        txt.setText(texto);

    }
}
