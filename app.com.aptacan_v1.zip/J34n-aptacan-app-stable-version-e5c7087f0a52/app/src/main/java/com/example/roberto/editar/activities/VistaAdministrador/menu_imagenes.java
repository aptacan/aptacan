package com.example.roberto.editar.activities.VistaAdministrador;


import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.esafirm.imagepicker.features.IpCons;
import com.esafirm.imagepicker.model.Image;
import com.example.roberto.editar.R;

import com.esafirm.imagepicker.features.ImagePicker;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class menu_imagenes extends Activity {

    private static final int ACTIVITY_SELECT_IMAGE = 1020;
    private final int PICK_IMAGE_MULTIPLE = 1;

    @BindView(R.id.newimage) Button boton_nuevaImagen;
    @BindView(R.id.seeimages) Button boton_verImagenes;


    @OnClick(R.id.newimage)
    public void abrirGaleriaDeImagenes(View view) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {

            Intent galleryIntent = new Intent(Intent.ACTION_PICK);
            galleryIntent.setDataAndType(
                    MediaStore.Images.Media.INTERNAL_CONTENT_URI,
                    "image/*"
            );
            galleryIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);

            startActivityForResult(
                    Intent.createChooser(galleryIntent, "Qué aplicación desea utilizar?"),
                    ACTIVITY_SELECT_IMAGE
            );
        } else {
            startActivityForResult(ImagePicker.create(this)
                    .multi()
                    .getIntent(this), IpCons.RC_IMAGE_PICKER);
        }
    }



    @OnClick(R.id.seeimages)
    public void verImagenes(View view) {
        Intent i = new Intent(menu_imagenes.this, GridViewElementosImagenes2.class);
        startActivity(i);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_imagenes);
        ButterKnife.bind(this);
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == ACTIVITY_SELECT_IMAGE && resultCode == RESULT_OK) {
            Uri ImageUri = data.getData();

            if (ImageUri != null) {
                cargaImagen(ImageUri);
            } else {
                ClipData lista = data.getClipData();
                int numimag = 0;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                    numimag = Objects.requireNonNull(lista).getItemCount();
                }

                for (int im = 0; im < numimag; im++) {
                    Uri sigimag = lista.getItemAt(im).getUri();
                    Log.i("<STRING TO URI>: " , "RESULTADO:  " + lista.getItemAt(im).getUri());
                    cargaImagen(sigimag);
                }
            }
        }


        if (ImagePicker.shouldHandle(requestCode, resultCode, data)) {
            // Get a list of picked images
            List<Image> images = ImagePicker.getImages(data);
            // or get a single image only
//            Image image = ImagePicker.getFirstImageOrNull(data);
            Log.i("<STRING TO URI>: " , "RESULTADO:  " + Uri.parse(images.get(0).getPath()));
            for(Image image : images) {
                cargaImagen(image.getPath());
            }

        }
    }


    protected void cargaImagen(Uri imagenUri) {
        Bitmap imagebitmap = getImage(imagenUri);
        String imageName = getImageName(imagenUri);
//        Log.i("<IMAGEN NOMBRE>: ", "nombre imagen: " + getImageName("/usr/image/imagen.png"));

        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        File mypath = new File(directory, imageName + ".jpg");

        FileOutputStream fos;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            imagebitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    protected void cargaImagen(String rutaImg) {
        Log.i("<IMAGEN NOMBRE>: ", "nombre imagen: " + getImageName(rutaImg));
        Bitmap bitmapImg = BitmapFactory.decodeFile(rutaImg);
        String nombreImg = getImageName(rutaImg);

        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        File nuevaImg = new File(directory, nombreImg);

        FileOutputStream fileOutputStream;
        try {
            fileOutputStream = new FileOutputStream(nuevaImg);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImg.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
            fileOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }



    public Bitmap getImage(Uri uri) {

        Bitmap result = null;
        BitmapFactory.Options options = new BitmapFactory.Options();
        InputStream is;
        try {
            Context mContext=getApplicationContext();
            is = mContext.getContentResolver().openInputStream(uri);
            result = BitmapFactory.decodeStream(is, null, options);
            assert is != null;
            is.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        return result;
    }



    private String getImageName(String picturePath){
        try{

            Integer pos= null;
            if (picturePath != null) {
                pos = picturePath.lastIndexOf("/");
            }
            String name= null;
            if (picturePath != null) {
                name = picturePath.substring(pos + 1);
            }
            if (name != null) {
                pos=name.lastIndexOf(".");
            }
            if (name != null) {
                name=name.substring(0,name.length());
            }

            return name;}
        catch (NullPointerException e){
            e.printStackTrace();
            return null;
        }
    }




    private String getImageName(Uri intentUri) {
        String nombreImagen;
        Cursor returnCursor = getContentResolver().query(
                intentUri,
                null,
                null,
                null,
                null
        );
        /*
         * obtiene los indices de las columnas presentes en los datos, y los setea en el Cursor,
         * se mueve a la primera fila en el cursor, obtiene los datos y los muestra.
         */
        assert returnCursor != null;
        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        int sizeIndex = returnCursor.getColumnIndex(OpenableColumns.SIZE);
        returnCursor.moveToFirst();
//        Log.i("------Datos de imagen: ", "Nombre de archivo: " + returnCursor.getString(nameIndex));
        nombreImagen = returnCursor.getString(nameIndex);
        returnCursor.close();

        return nombreImagen;
    }
}