package com.example.roberto.editar.adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.roberto.editar.models.ElementsWorks;
import com.example.roberto.editar.R;

import java.util.ArrayList;
import java.util.Locale;

// Please take care of textView.setText with concat of no string arguments
public class ElementsWorksAdapter extends BaseAdapter{
    private Context context;
    private LayoutInflater inflater;
    public ArrayList<ElementsWorks> dataSourceElements;

    public ElementsWorksAdapter(Context c, ArrayList<ElementsWorks> d) {

        this.context = c;
        this.dataSourceElements= d;
        this.inflater = LayoutInflater.from(c);

    }

    public int getCount() {
        return this.dataSourceElements.size();
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

                  View view = this.inflater.inflate(R.layout.works_elements_info, null);
                Integer _id = this.dataSourceElements.get(position).getId();
        Integer id_elemento = this.dataSourceElements.get(position).getElemento();
              String prompt = this.dataSourceElements.get(position).getPrompt();
              String nombre = this.dataSourceElements.get(position).getENombre();
           Integer posicion = this.dataSourceElements.get(position).getPosicion();
              Integer datos = this.dataSourceElements.get(position).getDatos();

              Log.i("[ADAPTER]", "[[]] -> " + _id);

        ((TextView) view.findViewById(R.id._idET)).setText(String.valueOf(_id));
        ((TextView) view.findViewById(R.id.Id_elemento)).setText(String.valueOf(id_elemento));
        ((TextView)view.findViewById(R.id.Nombre)).setText(nombre);
        ((TextView) view.findViewById(R.id.Prompt)).setText(prompt);
        ((TextView)view.findViewById(R.id.Posicion)).setText(String.format("Posición: %s", posicion));
        ((TextView)view.findViewById(R.id.Datos)).setText(String.format("Datos:    %s", datos.toString()));
        (view.findViewById(R.id.imageButton3)).setOnClickListener((View.OnClickListener) this.context);
        (view.findViewById(R.id.imageButton4)).setOnClickListener((View.OnClickListener) this.context);
        return view;
    }
}
