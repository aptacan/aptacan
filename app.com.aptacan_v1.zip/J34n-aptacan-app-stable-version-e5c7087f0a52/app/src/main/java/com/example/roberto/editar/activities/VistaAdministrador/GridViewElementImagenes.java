package com.example.roberto.editar.activities.VistaAdministrador;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import com.example.roberto.editar.R;
import com.example.roberto.editar.adapters.GridViewAdapter;

import java.io.File;
import java.util.ArrayList;


public class GridViewElementImagenes extends Activity implements AdapterView.OnItemClickListener {

    private GridView gridView;
    private GridViewAdapter gridAdapter;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_view_element);
        Log.i("<ACTIVITY>", "<GridViewElementImagenes EJECUTANDOSE>");

        gridView = findViewById(R.id.gridView_listaDeTrabajos);
        gridAdapter = new GridViewAdapter(
                this,
                R.layout.gridview_item_imagen,
                listarImgsEnDirImagenes()
        );

        gridView.setAdapter(gridAdapter);
        gridView.setOnItemClickListener(this);
    }



    private ArrayList<String> listarImgsEnDirImagenes() {
        ArrayList<String> images = new ArrayList<>();

        ContextWrapper contextWrapper = new ContextWrapper(getApplicationContext());
        File directory = contextWrapper.getDir("imageDir", Context.MODE_PRIVATE);

        File[] files = directory.listFiles();
        //Hacemos un Loop por cada fichero para extraer el nombre de cada uno
        for (File file : files) {
            if (file.isDirectory())
                images.add(file.getName() + "/");
            else
                images.add(file.getPath());
        }

        return images;
    }



    public void onItemClick(AdapterView<?> parent, final View view, final int position, long id) {

        AlertDialog.Builder dialogoEscogerImg = new AlertDialog.Builder(this);
        dialogoEscogerImg.setTitle("IMPORTANTE");
        dialogoEscogerImg.setMessage("¿ Quieres escoger la imagen, Seguro ?");
        dialogoEscogerImg.setCancelable(false);

        dialogoEscogerImg.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {
                gridAdapter.remove(position);

                TextView imageTitle = view.findViewById(R.id.text);
                final String title = imageTitle.getText().toString();

                Intent intent=new Intent();
                intent.putExtra("MESSAGE",title);

                setResult(2,intent);
                finish();//finishing activity
            }
        });

        dialogoEscogerImg.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {
                finish();
            }
        });
        dialogoEscogerImg.show();
    }

}

