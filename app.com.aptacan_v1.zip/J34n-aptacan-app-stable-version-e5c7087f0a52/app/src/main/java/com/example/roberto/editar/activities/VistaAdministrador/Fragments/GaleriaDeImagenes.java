package com.example.roberto.editar.activities.VistaAdministrador.Fragments;


import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.esafirm.imagepicker.features.ImagePicker;
import com.esafirm.imagepicker.features.IpCons;
import com.esafirm.imagepicker.model.Image;
import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.ComprobarUsoImagen;
import com.example.roberto.editar.activities.VistaAdministrador.GridViewElementosImagenes2;
import com.example.roberto.editar.adapters.GridViewAdapter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.OnClick;

import static android.app.Activity.RESULT_OK;

/**
 * A simple {@link Fragment} subclass.
 */
public class GaleriaDeImagenes extends Fragment implements AdapterView.OnItemClickListener {

    private static final int ACTIVITY_SELECT_IMAGE = 1020;

    private GridViewAdapter gridAdapter;
    private GridView gridView;
    private ArrayList<String> datos;
    private Activity activity;
    private File dirImagenes;



    public GaleriaDeImagenes() {
        // Required empty public constructor
    }


    @OnClick(R.id.fabButton)
    public void abrirGalleriaImagenes() {

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {

            Intent galleryIntent = new Intent(Intent.ACTION_PICK);
            galleryIntent.setDataAndType(
                    MediaStore.Images.Media.INTERNAL_CONTENT_URI,
                    "image/*"
            );
            galleryIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);

            startActivityForResult(
                    Intent.createChooser(galleryIntent, "Qué aplicación desea utilizar?"),
                    ACTIVITY_SELECT_IMAGE
            );
        } else {
            startActivityForResult(ImagePicker.create(this)
                    .multi()
                    .getIntent(activity), IpCons.RC_IMAGE_PICKER);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        //Libreria ImgPicker para Android 4.3 o inferiores
        if (ImagePicker.shouldHandle(requestCode, resultCode, data)) {
            Log.i("<IMGPICKER>: ", "Ha entrado ImgPicker /////!!!!");

            List<Image> images = ImagePicker.getImages(data);

            Log.i("<STRING TO URI>: " , "RESULTADO:  " + Uri.parse(images.get(0).getPath()));

            for(Image image : images) {
                String rutaArchivoImage = image.getPath();
                CargadorDeImagenes cargadorDeImagenes = new CargadorDeImagenes();
                cargadorDeImagenes.execute(rutaArchivoImage);
            }
        } else {
            //Imagenes multiples para Android 4.4 o superiores
            obtenerImgsDeGalleria(requestCode, resultCode, data);
        }
    }


    @TargetApi(Build.VERSION_CODES.KITKAT)
    private void obtenerImgsDeGalleria(final int requestCode, final int resultCode,final Intent data) {

        if(requestCode == ACTIVITY_SELECT_IMAGE && resultCode == RESULT_OK) {
            Uri ImageUri = data.getData();

            if (ImageUri != null) {
                CargadorDeImagenes cargadorDeImagenes = new CargadorDeImagenes();
                cargadorDeImagenes.execute(ImageUri);
            } else {

                ClipData listaImagenesUri = data.getClipData();

                if (listaImagenesUri != null) {
                    final int cantidadDeImagenes = listaImagenesUri.getItemCount();

                    for (int contador = 0; contador < cantidadDeImagenes; contador++) {
                        Uri imagenUri = listaImagenesUri.getItemAt(contador).getUri();

                        CargadorDeImagenes cargadorDeImagenes = new CargadorDeImagenes();
                        cargadorDeImagenes.execute(imagenUri);

                        Log.i("<STRING TO URI>: ", "RESULTADO:  " + listaImagenesUri.getItemAt(contador).getText());
                    }
                }

            }

        }
    }


    protected void cargaImagen(Object imagenRuta) {
        Bitmap imagenBitmap = null;
        String nombreDeImagen = "";

        if (imagenRuta instanceof Uri) {
            imagenBitmap = getImage((Uri) imagenRuta);
            nombreDeImagen = getImageName((Uri) imagenRuta);
            Log.i("<INSTANCIA DE>: ", "[Es un Uri]");

        } else if (imagenRuta instanceof String) {
            imagenBitmap = BitmapFactory.decodeFile((String) imagenRuta);
            nombreDeImagen = getImageName((String) imagenRuta);
            Log.i("<INSTANCIA DE>: ", "[Es un StringPath]");
        }

        if(imagenBitmap != null) {
            File nuevaImagen = new File(dirImagenes, nombreDeImagen);

            try {
                FileOutputStream fileOutputStream = new FileOutputStream(nuevaImagen);
                // Use the compress method on the BitMap object to write image to the OutputStream
                imagenBitmap.compress(
                        Bitmap.CompressFormat.JPEG,
                        100,
                        fileOutputStream
                );
                fileOutputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            datos.add(nuevaImagen.getPath());
        }
    }


    public Bitmap getImage(Uri uri) {
        Bitmap result = null;
        BitmapFactory.Options options = new BitmapFactory.Options();

        try {
            InputStream is = activity.getContentResolver().openInputStream(uri);
            result = BitmapFactory.decodeStream(is, null, options);
            assert is != null;
            is.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }


    private String getImageName(String picturePath){
        try{
            Integer pos = null;
            if (picturePath != null) {
                pos = picturePath.lastIndexOf("/");
            }
            String name = null;
            if (picturePath != null) {
                name = picturePath.substring(pos + 1);
            }
            if (name != null) {
                pos=name.lastIndexOf(".");
            }
            if (name != null) {
                name=name.substring(0,name.length());
            }
            return name;
        }
        catch (NullPointerException e){
            e.printStackTrace();
            return null;
        }
    }


    private String getImageName(Uri intentUri) {

        final Cursor returnCursor = activity.getContentResolver().query(
                intentUri,
                null,
                null,
                null,
                null
        );
        /*
         * obtiene los indices de las columnas presentes en los datos, y los setea en el Cursor,
         * se mueve a la primera fila en el cursor, obtiene los datos y los muestra.
         */
        assert returnCursor != null;
        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        returnCursor.moveToFirst();

        final String nombreImagen = returnCursor.getString(nameIndex);
        returnCursor.close();

        return nombreImagen;
    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        this.activity = getActivity();
        View view = inflater.inflate(
                R.layout.fragment_galeria_de_imagenes,
                container,
                false
        );
        ButterKnife.bind(this, view);

        ContextWrapper cw = new ContextWrapper(activity.getApplicationContext());
        dirImagenes = cw.getDir("imageDir", Context.MODE_PRIVATE);

        gridView = view.findViewById(R.id.gridView);

        datos = getListaArchivosImgs();
        gridAdapter = new GridViewAdapter(activity, R.layout.gridview_item_imagen, datos);
        gridView.setAdapter(gridAdapter);
        gridView.setOnItemClickListener(this);
//        FloatingActionButton fab = view.findViewById(R.id.fabButton);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(activity, "confirmacion de clickeo", Toast.LENGTH_SHORT).show();
//            }
//        });



        // Inflate the layout for this fragment
        return view;
    }



    private ArrayList<String> getListaArchivosImgs() {
        ArrayList<String> images = new ArrayList<>();

        File[] archivosImgs = dirImagenes.listFiles();

        //Hacemos un Loop por cada fichero para extraer el nombre de cada uno
        //Sacamos del array files un fichero
        for(File archivoImg : archivosImgs) {
            if (archivoImg.isDirectory())
                images.add(archivoImg.getName() + "/");
            else
                images.add(archivoImg.getPath());
        }

        return images;
    }



    public void onItemClick(AdapterView<?> parent, final View view, final int position, long id) {

        TextView imageTitle = view.findViewById(R.id.text);
        String title = imageTitle.getText().toString();
        ComprobarUsoImagen existe = new ComprobarUsoImagen(activity, title);
        Boolean result = existe.doInBackground(title);
        AlertDialog.Builder dialogo1;

        if (result){
            dialogo1= new AlertDialog.Builder(activity);
            dialogo1.setTitle("IMPORTANTE");
            dialogo1.setMessage("La imagen está en uso no se puede eliminar.");
            dialogo1.setCancelable(false);
            dialogo1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });

        } else{
            dialogo1 = new AlertDialog.Builder(activity);
            dialogo1.setTitle("IMPORTANTE");
            dialogo1.setMessage("¿ Quieres eliminar la imagen, Seguro ?");
            dialogo1.setCancelable(false);
            dialogo1.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    gridAdapter.remove(position);
                    TextView imageTitle = view.findViewById(R.id.text);
                    String title=imageTitle.getText().toString();
                    borrarImagen(title);
                }
            });
            dialogo1.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
        }
        dialogo1.show();

    }


    //metodo para permitir la entrada de nuevos numeros,escribir.
    private void borrarImagen(String nombreArchivoImg) {
        String msg;

        File mypath = new File(dirImagenes, nombreArchivoImg);
        boolean fueBorradoElArchivo = mypath.delete();

        if (fueBorradoElArchivo)
            msg = "El elemento se ha borrado";
        else
            msg = "El elemento NO se ha borrado";

        Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show();
    }


    public class CargadorDeImagenes extends AsyncTask<Object, Void, Boolean> {

        private List<Image> listaImagenes;
        private String imagen;



        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected Boolean doInBackground(Object... imagenes) {
            cargaImagen(imagenes[0]);

            return true;
        }


        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);
            if(aBoolean)
                gridAdapter.notifyDataSetChanged();

        }
    }
}
