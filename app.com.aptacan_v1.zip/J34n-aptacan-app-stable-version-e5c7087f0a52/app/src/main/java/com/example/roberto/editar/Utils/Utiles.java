package com.example.roberto.editar.Utils;

import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.roberto.editar.R;
import com.example.roberto.editar.models.Rango;

import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;

import static android.content.Context.WINDOW_SERVICE;

public class Utiles {

    public static final int BOTON_ID = 10;
    private static final String nombreDirDeImagenes = "imageDir";




    public static boolean isDobleCaraActivated = false;



    public static int getValorRango(String entradaRango) {

        if(entradaRango.contains("-")) {
            int inicio = Integer.parseInt(
                    entradaRango.substring(0, entradaRango.indexOf("-"))
            );
            int fin = Integer.parseInt(
                    entradaRango.substring(entradaRango.lastIndexOf("-") + 1)
            );
            return Math.abs(fin - inicio) + 1;
        }
        return Integer.parseInt(entradaRango);
    }



    public static Rango getValorRangoUtil(String entradaRango) {
        Rango rango = new Rango();
        int inicio = 0;
        int fin = 0;
        int cantidad = 0;

        if(entradaRango.contains("-")) {
            inicio = Integer.parseInt(
                    entradaRango.substring(0, entradaRango.indexOf("-"))
            );
            fin = Integer.parseInt(
                    entradaRango.substring(entradaRango.lastIndexOf("-") + 1)
            );
            rango.setInicio(inicio);
            rango.setFin(fin);
            rango.setCantidad(Math.abs(fin - inicio) + 1);
            return rango;
        }


        rango.setInicio(1);
        rango.setFin(Integer.parseInt(entradaRango));
        rango.setCantidad(Integer.parseInt(entradaRango));
        return rango;
    }


    public static Drawable crearDrawable(Context context, String Icono) {
        if(!Icono.equals("")) {
            ContextWrapper contextWrapper = new ContextWrapper(context);
            File directorioImagenes = contextWrapper.getDir(nombreDirDeImagenes, Context.MODE_PRIVATE);
            String rutaImagen = directorioImagenes.toString() + "/" + Icono;
            File imagen = new File(rutaImagen);

            if(imagen.exists()) {
                return Drawable.createFromPath(rutaImagen);
            }
        }
        return null;
    }


    public static boolean isNull(Object objeto) {
        return objeto == null;
    }


    // contexto, nombreDeImagen, View,
    public static void cargarImg(Context contexto, View view, String nombreImg) {
        ContextWrapper contextWrapper = new ContextWrapper(contexto);
        File dirImagenes = contextWrapper.getDir(nombreDirDeImagenes, Context.MODE_PRIVATE);

        File archivoIcono = new File(dirImagenes, nombreImg);

        Glide.with(contexto)
                .load(archivoIcono.getPath())
                .apply(
                        new RequestOptions()
                                .override(100, 100)
                                .error(R.drawable.nocamera)
                ).into((ImageView) view);
    }



    public static double round(double value, int places) {
        double scale = Math.pow(10, places);
        return Math.round(value * scale) / scale;
    }


    public static double redondearExacto(double numero,int digitos){
        String val = numero+"";
        BigDecimal big = new BigDecimal(val);
        big = big.setScale(2, RoundingMode.HALF_UP);
        return big.doubleValue();
    }


    public static int[] medirPantalla(Context context) {
        int[] medidas = {0, 0}; //x, y
        WindowManager windowManager = (WindowManager) context
                .getSystemService(WINDOW_SERVICE);

        Display display = windowManager.getDefaultDisplay();

        Point size = new Point();
        display.getSize(size);

        float x = size.x / 10;
        float y = size.y / 10;

        medidas[0] = (int) x;
        medidas[1] = (int) y;
        return medidas;
    }


    public static void imprimirArrayStr(ArrayList<String> datos) {
        int contador = 0;
        for (String dato :
                datos) {
            Log.i("<ImprimiendoArray>: ", "Dato " + contador + ": " + dato);
            contador++;
        }
    }


}
