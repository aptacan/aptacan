package com.example.roberto.editar.models;


import android.app.Activity;
import android.content.Context;
import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.roberto.editar.R;

import java.util.ArrayList;

public class Tablero {
    ArrayList objetos;
    Object [] cosas;

//    public Tablero(ArrayList<Pagina> objetos) {
//        this.objetos = objetos;
//    }

    public Tablero(ArrayList objetos) {
        this.objetos = objetos;
    }

    public Tablero() {}


    public ArrayList<Moneda> arrayToMonedas(float[] valores, String[] nombres, int[] imgsViewID, int[] imgsDrawableID) {
        ArrayList<Moneda> monedas = new ArrayList<>();

        for(int i = 0; i < imgsDrawableID.length; i++) {
            Moneda moneda = new Moneda(
                    i,
                    valores[i],
                    nombres[i],
                    imgsViewID[i],
                    imgsDrawableID[i]
            );
            monedas.add(moneda);
        }
        return monedas;
    }

    public void cargarImagenes(Context contexto, int x, int y, ArrayList objetos) {

        Activity activity = ((Activity) contexto);

        if(!objetos.isEmpty()) {

            if(objetos.get(0) instanceof Moneda) {
                for(int i = 0; i < objetos.size(); i++) {
                    Moneda moneda = (Moneda)objetos.get(i);
                    dibujarImg(contexto, x, y, moneda.ImgButtonID, moneda.ImgDrawableID);
                }

            } else if(objetos.get(0) instanceof Pagina) {
                for(int i = 0; i < objetos.size(); i++) {
                    Pagina pagina = (Pagina) objetos.get(i);
                    dibujarImg(contexto, x, y, pagina.ImgButtonID, pagina.ImgDrawableID);
                }

            }
        }

    }



    private void dibujarImg(Context contexto, int x, int y, int imgViewId, int imgDrawableId) {
        Activity activity = ((Activity) contexto);
//        ImageView m = new ImageButton(contexto);




//        Log.i("<BOTON INFO>", "id boton: " + m.getId());
        ImageView imageView = activity.findViewById(imgViewId);
        imageView.setImageDrawable(activity.getResources().getDrawable(R.drawable.noimg));

        Glide.with(contexto)
                .load(imgDrawableId)
                .apply(new RequestOptions().override(x, y))
                .into(imageView);
    }

}
