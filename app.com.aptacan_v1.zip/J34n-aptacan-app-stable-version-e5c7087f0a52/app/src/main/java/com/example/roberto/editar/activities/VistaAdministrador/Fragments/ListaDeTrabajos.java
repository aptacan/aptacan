package com.example.roberto.editar.activities.VistaAdministrador.Fragments;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.DbControl;
import com.example.roberto.editar.activities.VistaAdministrador.ListaDeElementosTrabajos;
import com.example.roberto.editar.activities.VistaAdministrador.TRABAJO;
import com.example.roberto.editar.adapters.WorksAdapter;
import com.example.roberto.editar.models.Works;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class ListaDeTrabajos extends Fragment implements AdapterView.OnItemClickListener, View.OnClickListener {

    private DbControl dbadapter;
    Boolean titulo = false;
    private Activity activity;
    private View view;


    public ListaDeTrabajos() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lista_de_trabajos, container, false);
        this.activity = getActivity();

        Log.i("<ACVITITY>: ", "___[ ListaDeTrabajosActivity ¡EJECUTADO! ]___");


        FloatingActionButton boton = view.findViewById(R.id.fabButton);
        boton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(activity, TRABAJO.class);
                startActivityForResult(intent,1);
            }
        });


        // Inflate the layout for this fragment
        return view;
    }



    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        dbadapter = new DbControl(getContext());
        this.view = view;
        dbadapter.open();
        displayListView(view);
        dbadapter.close();
        super.onViewCreated(view, savedInstanceState);
    }

    private void displayListView(View view){
        try {

            ArrayList<Works> trabajos = this.creardatos();



            for (Works trabajo:
                 trabajos) {
                Log.i("<DATOS DE TRABAJOS>: ", "Titulo -- >> " + trabajo.getTitulo());
            }



            WorksAdapter adapter = new WorksAdapter(getActivity(), trabajos, this);

            ListView listView = view.findViewById(R.id.ListViewTrabajos);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(this);

            //.........Creating a Header for ListView..........
            //Initialize a new TextView instance
            if (!titulo) {
                TextView tv = new TextView(activity);
                //Set a text for TextView widget
                tv.setText(R.string.listatrabajos);
                //Apply TextView text color to MediumSlateBlue
                tv.setTextColor(Color.BLACK);
                tv.setGravity(Gravity.CENTER_HORIZONTAL);
                tv.setPadding(15, 15, 15, 15);
                //Set the TextView as ListView Header and it is non selectable
                listView.addHeaderView(tv, "este es un encabezado", false);
            }
            titulo=true;
        }
        catch(Exception e){
            AlertDialog.Builder builder =
                    new AlertDialog.Builder(activity);

            builder.setMessage("Esto es un mensaje de alerta.")
                    .setTitle("Información")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
        }

    }

//    @Override
//    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
//        inflater.inflate(R.menu.menu_list_view_works, menu);
//        super.onCreateOptionsMenu(menu, inflater);
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            activity.finish();//return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }


    @Override
    public void onClick(View v) {
        View view = (View) v.getParent();

        if(v.getId() == R.id.imageButton) {
            Intent intento = new Intent(activity,TRABAJO.class);
            intento.putExtra("_id",((TextView)view.findViewById(R.id._id)).getText());
            intento.putExtra("titulo",((TextView)view.findViewById(R.id.titulo)).getText());
            intento.putExtra("precio", ((TextView)view.findViewById(R.id.precio)).getText());
            intento.putExtra("icono",((TextView)view.findViewById(R.id.textView_nombreIcono)).getText());
            startActivityForResult(intento,1);
        }else if(v.getId() == R.id.imageButton2){
            AlertDialog dialogo1;
            dialogo1=crearDialogoConexion(((TextView)view.findViewById(R.id._id)).getText().toString());
            dialogo1.show();

        }

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        String trabajo = ((TextView) view.findViewById(R.id._id))
                .getText().toString();
        String titulo = ((TextView) view.findViewById(R.id.titulo))
                .getText().toString();
        Intent intento = new Intent(activity, ListaDeElementosTrabajos.class);
        intento.putExtra("Trabajo", trabajo);
        intento.putExtra("titulo", titulo);
        startActivity(intento);
    }

    private ArrayList<Works> creardatos(){
        try {
            ArrayList<Works> list = new ArrayList<>();
            // Columnas de la tabla trabajos
            String KEY_ID = "_id";
            String KEY_COL1 = "titulo";
            String KEY_COL2 = "icono";
            String KEY_COL3 = "precio";
            //Array de strings para su uso en los diferentes métodos
            String[] cols = new String[]{KEY_ID, KEY_COL1, KEY_COL2, KEY_COL3};

            Cursor cursor = dbadapter.allTrabajos(cols);
            if (cursor.moveToFirst()) {
                do {
                    Works libro = new Works(cursor.getInt(0), cursor.getString(1), cursor.getString(2),
                            cursor.getDouble(3));
                    list.add(libro);
                    Log.i("<PATH>", "trabajo: " + libro.getTitulo() + " | icono: " + libro.getIcono());
                } while (cursor.moveToNext());
            }
            if (!cursor.isClosed()) {
                cursor.close();
            }
            return list;
        }
        catch (Exception e){
            AlertDialog.Builder builder =
                    new AlertDialog.Builder(activity);

            builder.setMessage("Esto es un mensaje de alerta.")
                    .setTitle("Información")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            return null;
        }
    }



    private AlertDialog crearDialogoConexion(final String _id)
    {
        // Instanciamos un nuevo AlertDialog Builder y le asociamos titulo y mensaje
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(activity);
        alertDialogBuilder.setTitle("IMPORTANTE");
        alertDialogBuilder.setMessage("¿ Quieres eliminar el trabajo, Seguro ?");
        alertDialogBuilder.setCancelable(false);
        // Creamos un nuevo OnClickListener para el boton OK que realice la conexion
        DialogInterface.OnClickListener listenerOk = new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Intent intent = new Intent(ListaDeTrabajosActivity.this,Administracion.class);
                String clausula="Trabajo=?";
                String[] Args = new String[] {_id};
                dbadapter.open();
                dbadapter.Eliminar("Datos",clausula,Args);
                dbadapter.Eliminar("Elementos_Trabajos",clausula,Args);
                dbadapter.removework(_id);
                dbadapter.close();
                //startActivity(intent);
                activity.finish();
            }
        };

        // Creamos un nuevo OnClickListener para el boton Cancelar
        DialogInterface.OnClickListener listenerCancelar = new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                activity.finish();
            }
        };

        // Asignamos los botones positivo y negativo a sus respectivos listeners
        alertDialogBuilder.setPositiveButton(R.string.Confirmar, listenerOk);
        alertDialogBuilder.setNegativeButton(R.string.Cancelar, listenerCancelar);

        return alertDialogBuilder.create();
    }
//

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        dbadapter.open();

        displayListView(view);

        dbadapter.close();
    }

}
