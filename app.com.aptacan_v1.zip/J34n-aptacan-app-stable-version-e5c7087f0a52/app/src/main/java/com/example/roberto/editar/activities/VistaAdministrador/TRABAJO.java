package com.example.roberto.editar.activities.VistaAdministrador;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.DbControl;

public class TRABAJO extends Activity implements ImageView.OnClickListener{

    private static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 1;


    private DbControl dbadapter;
    private Boolean editar = false;
    private static int RESULT_LOAD_IMAGE = 1;
    private static final int ACTIVITY_SELECT_IMAGE = 1020;
    private Activity activity;
    private File dirImagenes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trabajo);
        dbadapter = new DbControl(this);
        (findViewById(R.id.imageView2)).setOnClickListener(this);
        Intent intent = getIntent();

        if (intent.getExtras() != null) {
            EditText txttitulo = (EditText) findViewById(R.id.editText3);
            txttitulo.setText(intent.getExtras().getString("titulo"));

            EditText txtprecio = (EditText) findViewById(R.id.editText4);
            txtprecio.setText(intent.getExtras().getString("precio"));

            TextView txtid = (TextView) findViewById(R.id.textView7);
            txtid.setText(intent.getExtras().getString("_id"));

            txtid = (TextView) findViewById(R.id.textView46);
            String icono = intent.getExtras().getString("icono");
            txtid.setText(icono);

            ImageView image = (ImageView) findViewById(R.id.imageView2);

            ContextWrapper cw = new ContextWrapper(getApplicationContext());
            File directory = cw.getDir("dirImagenes", Context.MODE_PRIVATE);
            File mypath = null;
            if (icono != null) {
                mypath = new File(directory,icono );
            }
            Glide.with(image.getContext())
                    .load(mypath.getPath())
                    .apply(
                            new RequestOptions().override(300, 300)
                                    .error(R.drawable.nocamera) )
                    .into(image);
            editar = true;
        }
        Button boton = (Button) findViewById(R.id.button4);
        boton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    dbadapter.open();
                    if (editar) {
                        EditText txttitulo = (EditText) findViewById(R.id.editText3);
                        EditText txtprecio = (EditText) findViewById(R.id.editText4);
                        TextView txtid = (TextView) findViewById(R.id.textView7);
                        TextView txticono = (TextView) findViewById(R.id.textView46);
                        String valor=txtprecio.getText().toString();
                        Double precio=Double.valueOf(valor.replace(",", "."));
                        //precio=Double.parseDouble(txtprecio.getText().toString());
                        dbadapter.updateWork(txtid.getText().toString(), txttitulo.getText().toString(), precio, txticono.getText().toString());
                    } else {
                        EditText txttitulo = (EditText) findViewById(R.id.editText3);
                        EditText txtprecio = (EditText) findViewById(R.id.editText4);
                        TextView txticono = (TextView) findViewById(R.id.textView46);
                        dbadapter.insertWork(txttitulo.getText().toString(), Double.parseDouble(txtprecio.getText().toString()), txticono.getText().toString());
                    }
                   /* Intent intento = new Intent(TRABAJO.this, ListaDeTrabajosActivity.class);
                    startActivity(intento);*/
                   finish();
                }catch(Exception e){
                    return;
                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_trabajo, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            finish();//return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
//        if (requestCode == RESULT_LOAD_IMAGE && null != data) {
//            String message = data.getStringExtra("MESSAGE");
//            TextView txt = (TextView) findViewById(R.id.textView46);
//            txt.setText(message);
//            ImageView image = (ImageView) findViewById(R.id.imageView2);
//            //ContextWrapper cw = new ContextWrapper(getApplicationContext());
//            //File directory = cw.getDir("dirImagenes", Context.MODE_PRIVATE);
//            //File mypath = new File(directory, message);
//            //Bitmap imagen = BitmapFactory.decodeFile(mypath.getAbsolutePath());
//            //imagebutton.setImageBitmap(imagen);
//
//            ContextWrapper cw = new ContextWrapper(getApplicationContext());
//            File directory = cw.getDir("dirImagenes", Context.MODE_PRIVATE);
//            File mypath = new File(directory, message);
//            Glide.with(image.getContext())
//                    .load(mypath.getPath())
//                    .apply(new RequestOptions().override(100, 100))
//                    .into(image);
//        }

        Log.i("<PATH_ONREULT>", "requestCode: " + requestCode + "\nresultCode: " + resultCode + "\ndata: " + (data != null));


        if (requestCode == RESULT_LOAD_IMAGE) {

            if (data != null) {
                Uri selectedImage = data.getData();

                Log.i("<PATH>", "image path:///////////////////////// ");
                String[] filePathColumn = {MediaStore.Images.Media.DATA};

                assert selectedImage != null;
                Cursor cursor = getContentResolver().query(selectedImage,
                        filePathColumn, null, null, null);
                assert cursor != null;
                cursor.moveToFirst();

                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                String picturePath = cursor.getString(columnIndex);


                Log.i("<PATH>", "image path: " + picturePath);
                cursor.close();

                String message = getImageName(picturePath);
                TextView txt = (TextView) findViewById(R.id.textView46);
                txt.setText(message);

                ImageView image = (ImageView) findViewById(R.id.imageView2);

                ContextWrapper cw = new ContextWrapper(getApplicationContext());
                dirImagenes = cw.getDir("imageDir", Context.MODE_PRIVATE);
                File mypath = new File(dirImagenes, message);
                Log.i("<PATH>", "path: absoluto: " + mypath.getPath());
                cargaImagen(picturePath);

                Glide.with(image.getContext())
                        .load(picturePath)
                        .apply(new RequestOptions().override(100, 100))
                        .into(image);
            }

            Log.i("<PATH>", "request code: " + requestCode + "result OK: " + resultCode);
        }
    }


    @Override
    public void onClick(View v) {
//        Intent i = new Intent(this, GridViewElementImagenes.class);
//        startActivityForResult(i, RESULT_LOAD_IMAGE);
        abrirGalleriaImagenes();

    }


    public void abrirGalleriaImagenes() {

//            Intent galleryIntent = new Intent(Intent.ACTION_PICK);
//            galleryIntent.setDataAndType(
//                    MediaStore.Images.Media.INTERNAL_CONTENT_URI,
//                    "image/*"
//            );
//
//            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
//
//            startActivityForResult(
//                    Intent.createChooser(galleryIntent, "Qué aplicación desea utilizar?"),
//                    ACTIVITY_SELECT_IMAGE
//            );

        Intent i = new Intent(
                Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(i, RESULT_LOAD_IMAGE);

    }



    private String getImageName(String picturePath){
        try{
            Integer pos = null;
            if (picturePath != null) {
                pos = picturePath.lastIndexOf("/");
            }
            String name = null;
            if (picturePath != null) {
                name = picturePath.substring(pos + 1);
            }
            if (name != null) {
                pos=name.lastIndexOf(".");
            }
            if (name != null) {
                name=name.substring(0,name.length());
            }
            return name;
        }
        catch (NullPointerException e){
            e.printStackTrace();
            return null;
        }
    }


    private String getImageName(Uri intentUri) {

        final Cursor returnCursor = activity.getContentResolver().query(
                intentUri,
                null,
                null,
                null,
                null
        );
        /*
         * obtiene los indices de las columnas presentes en los datos, y los setea en el Cursor,
         * se mueve a la primera fila en el cursor, obtiene los datos y los muestra.
         */
        assert returnCursor != null;
        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        returnCursor.moveToFirst();

        final String nombreImagen = returnCursor.getString(nameIndex);
        returnCursor.close();

        return nombreImagen;
    }


    protected void cargaImagen(Object imagenRuta) {
        Bitmap imagenBitmap = null;
        String nombreDeImagen = "";

        if (imagenRuta instanceof Uri) {
            imagenBitmap = getImage((Uri) imagenRuta);
            nombreDeImagen = getImageName((Uri) imagenRuta);
            Log.i("<INSTANCIA DE>: ", "[Es un Uri]");

        } else if (imagenRuta instanceof String) {
            imagenBitmap = BitmapFactory.decodeFile((String) imagenRuta);
            nombreDeImagen = getImageName((String) imagenRuta);
            Log.i("<INSTANCIA DE>: ", "[Es un StringPath]");
        }

        if(imagenBitmap != null) {
            File nuevaImagen = new File(dirImagenes, nombreDeImagen);

            try {
                FileOutputStream fileOutputStream = new FileOutputStream(nuevaImagen);
                // Use the compress method on the BitMap object to write image to the OutputStream
                imagenBitmap.compress(
                        Bitmap.CompressFormat.JPEG,
                        100,
                        fileOutputStream
                );
                fileOutputStream.close();
                Log.i("<PATH>", "descomprimiento y seteando");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }



    public Bitmap getImage(Uri uri) {
        Bitmap result = null;
        BitmapFactory.Options options = new BitmapFactory.Options();

        try {
            InputStream is = activity.getContentResolver().openInputStream(uri);
            result = BitmapFactory.decodeStream(is, null, options);
            assert is != null;
            is.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }



    public void requestRead() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{ Manifest.permission.READ_EXTERNAL_STORAGE },
                    MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
        }

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        if (requestCode == MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.i("<PATH>", "Haciendo algo con el permiso");
            } else {
                // Permission Denied
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }


}
