package com.example.roberto.editar.activities.VistaAdministrador;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.DbControl;
import com.example.roberto.editar.adapters.ElementsWorksAdapter;
import com.example.roberto.editar.activities.Elemento;
import com.example.roberto.editar.models.ElementsWorks;

import java.util.ArrayList;

public class ListaDeElementosTrabajos extends AppCompatActivity implements AdapterView.OnItemClickListener,View.OnClickListener {

    private DbControl dbeadapter;
    private ElementsWorksAdapter adapter;
    private String _id;
    private Boolean titulo = false;
    private String trabajo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list__view__works__elements);
        Log.i("<ACVITITY>: ", "___[ ListaDeElementosTrabajos ¡EJECUTADO! ]___");

        setBotonRetrocesoEnActionBar();

        Intent intent = getIntent();

        _id = intent.getExtras().getString("Trabajo");
        trabajo = intent.getExtras().getString("titulo");
        getSupportActionBar().setTitle(trabajo);

        dbeadapter = new DbControl(this);
        dbeadapter.open();

        displayListView(trabajo);

        FloatingActionButton boton = findViewById(R.id.fabButton);
        boton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(ListaDeElementosTrabajos.this, Elemento.class);
                intent.putExtra("trabajo", _id);
                intent.putExtra("nuevo", true);
                startActivityForResult(intent,1);
            }
        });
        Log.i(this.getLocalClassName(), "[[ejecucion]] --> ");
    }



    private void setBotonRetrocesoEnActionBar() {
        final ActionBar actionBar= getSupportActionBar();
        if(actionBar != null)
            actionBar.setDisplayHomeAsUpEnabled(true);
    }


    private void displayListView(String trabajo) {
        try {
            ArrayList<ElementsWorks> elementos = this.creardatos();
            adapter = new ElementsWorksAdapter(this, elementos);
            ListView lv = (ListView) findViewById(R.id.ListView2);

            //.........Creating a Header for ListView..........
            //Initialize a new TextView instance
            if (!titulo) {
                TextView tv = new TextView(this);
                //Set a text for TextView widget
                tv.setText(trabajo);
                //Apply TextView text color to MediumSlateBlue
                tv.setTextColor(Color.BLACK);
                tv.setGravity(Gravity.CENTER_HORIZONTAL);
                tv.setPadding(15, 15, 15, 15);
                //Set the TextView as ListView Header and it is non selectable
                lv.addHeaderView(tv, "", false);
            }
            titulo = true;
            lv.setAdapter(adapter);
            lv.setOnItemClickListener(this);
        } catch (Exception e) {
            return;
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_list__view__works__elements, menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings ) {

            dbeadapter.close();
            finish();//return true;
        }  else if(id == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }



    public void onClick(View v) {

        View view = (View) v.getParent().getParent();
        //Intent intento = new Intent(ListaDeElementosTrabajos.this,Elemento.class);
        //para editar elemento trabajo
        if (v.getId() == R.id.imageButton3) {
            Intent intento = new Intent(ListaDeElementosTrabajos.this, Elemento.class);
            intento.putExtra("nombre", ((TextView) view.findViewById(R.id.Nombre)).getText());
            intento.putExtra("posicion", ((TextView) view.findViewById(R.id.Posicion)).getText());
            intento.putExtra("datos", ((TextView) view.findViewById(R.id.Datos)).getText());
            intento.putExtra("etid", ((TextView) view.findViewById(R.id._idET)).getText());
            intento.putExtra("trabajo", _id);
            intento.putExtra("nuevo", false);
            startActivityForResult(intento,1);

        } else if (v.getId() == R.id.imageButton4) {
            final String etid = ((TextView) view.findViewById(R.id._idET)).getText().toString();
            AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
            dialogo1.setTitle("IMPORTANTE");
            dialogo1.setMessage("¿ Quieres eliminar el trabajo, Seguro ?");
            dialogo1.setCancelable(false);
            dialogo1.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    eliminarelemento(etid);
                    Intent intent = new Intent(ListaDeElementosTrabajos.this, ListaDeTrabajosActivity.class);
                    startActivityForResult(intent, 1);
                }
            });
            dialogo1.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dbeadapter.close();
                    finish();
                }
            });
            dialogo1.show();
        }

    }



    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        String elemento = ((TextView) view.findViewById(R.id.Nombre)).getText().toString();
        Toast.makeText(getApplicationContext(),
                elemento, Toast.LENGTH_SHORT).show();
    }



    private ArrayList<ElementsWorks> creardatos() {
        ArrayList<ElementsWorks> list = new ArrayList<ElementsWorks>();


        Cursor cursor = dbeadapter.ElementsofWork(_id);
        if (cursor.moveToFirst()) {
            do {
                ElementsWorks element = new ElementsWorks(cursor.getInt(0), cursor.getInt(1), cursor.getInt(2),
                        cursor.getString(3), cursor.getInt(4), cursor.getInt(5), cursor.getString(6));

                list.add(element);
            } while (cursor.moveToNext());
        }
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
        return list;
    }



    private void eliminarelemento(String idet) {
         dbeadapter.eliminarelemento(idet);
   }



    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        displayListView(trabajo);

    }
}
