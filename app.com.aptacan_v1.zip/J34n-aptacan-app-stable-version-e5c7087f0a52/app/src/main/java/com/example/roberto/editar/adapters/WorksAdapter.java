package com.example.roberto.editar.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.ContextWrapper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.roberto.editar.R;
import com.example.roberto.editar.models.Works;

import java.io.File;
import java.util.ArrayList;
import java.util.Locale;

public class WorksAdapter extends BaseAdapter {

    private Context context;
    private LayoutInflater inflater;
    public ArrayList<Works> dataSource;
    private View.OnClickListener listenerImageButton;

    public WorksAdapter(Context context, ArrayList<Works> works, View.OnClickListener listenerImageButtons) {

        this.context = context;
        this.dataSource = works;
        this.inflater = LayoutInflater.from(context);
        this.listenerImageButton = listenerImageButtons;

    }

    @Override
    public int getCount() {
        return this.dataSource.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        //Obtenemos la vista de la fila.
        @SuppressLint("ViewHolder") View view = inflater.inflate(R.layout.works_info, null);

        Log.i("datos de ListView: ", "medidas: " + view.getWidth());

        //Obtenemos todos los datos necesarios
        String titulo=this.dataSource.get(position).getTitulo();
        String icono=this.dataSource.get(position).getIcono();
        Double precio = this.dataSource.get(position).getPrecio();
        Integer _id = this.dataSource.get(position).getId();

        //Insertamos los datos en la fila
        ImageView imagen = view.findViewById(R.id.icono);
        ContextWrapper cw = new ContextWrapper(context);

        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        File mypath = new File(directory,icono);

        Glide.with(imagen.getContext())
                .load(mypath.getPath())
                .apply(
                        new RequestOptions()
                                .override(100, 100)
                                .error(R.drawable.nocamera)
                                .fitCenter()
                                .centerCrop()
                )
                .into(imagen);

        ((TextView) view.findViewById(R.id.titulo)).setText(titulo);
        ((TextView) view.findViewById(R.id.textView_nombreIcono)).setText(icono);
        ((TextView)view.findViewById(R.id.precio)).setText(String.format(Locale.ENGLISH, "%f", precio));
        ((TextView)view.findViewById(R.id._id)).setText(String.format(Locale.ENGLISH, "%d",_id));


        //Activamos el evento click en los botones
        view.findViewById(R.id.imageButton).setOnClickListener(listenerImageButton);
        view.findViewById(R.id.imageButton2).setOnClickListener(listenerImageButton);
        return view;
    }
}
