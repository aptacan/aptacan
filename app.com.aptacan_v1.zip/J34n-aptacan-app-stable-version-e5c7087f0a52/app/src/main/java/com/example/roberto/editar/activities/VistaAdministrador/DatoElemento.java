package com.example.roberto.editar.activities.VistaAdministrador;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.util.Util;
import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.Utiles;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import butterknife.ButterKnife;
import butterknife.OnClick;

public class DatoElemento extends AppCompatActivity implements View.OnClickListener{

    private static int CARGAR_IMAGEN = 1;
    String numero;
    private EditText dato_editTxt;
    private EditText precio_editTxt;
    private TextView dato_txtView;
    private TextView nombreDeIcono_TxtView;
    private ImageView icono_imgView;
    private static final int ACTIVITY_SELECT_IMAGE = 1020;
    private Activity activity;
    private static int RESULT_LOAD_IMAGE = 1;
    private File directory;
    private File dirImagenes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dato_elemento);
        ButterKnife.bind(this);
        Log.i("<--ACTIVITY!-->", "[DatoElemnto (Activity)]");

        Intent intent = getIntent();

        numero = intent.getStringExtra("numero");
        int elemento = intent.getIntExtra("elemento", 0);
        String dato = intent.getStringExtra("dato");
        String precio = intent.getStringExtra("precio");
        String icono = intent.getStringExtra("icono");

        LinearLayout icono_layout = findViewById(R.id.LinearLayout_icono);
        icono_layout.setVisibility(View.VISIBLE);
//        TextView dato_txtView = findViewById(R.id.textView22);
        dato_txtView = findViewById(R.id.textView_dato);
        dato_txtView.setText(String.format("Dato %s:", numero));

        dato_editTxt = findViewById(R.id.editText_dato);
        dato_editTxt.setText(dato);

        precio_editTxt = findViewById(R.id.editText_precio);
        precio_editTxt.setText(precio);

        nombreDeIcono_TxtView = findViewById(R.id.textView_nombreIcono);
        icono_imgView = findViewById(R.id.imageView_icono);

        Utiles.cargarImg(this, icono_imgView, icono);


        // opciones(radioButton) o desplegable(spinner)?
        if ((elemento == 3 || elemento == 5)) {
            Log.i("<el elemento>", "numero: " + numero);
            if (Integer.parseInt(numero) != 1) { // no es el primer elementoDato?

                final String nombreDeIcono = intent.getStringExtra("icono");

                nombreDeIcono_TxtView.setText(nombreDeIcono);

                Utiles.cargarImg(this, icono_imgView, nombreDeIcono);
            } else {
                icono_layout.setVisibility(View.GONE);
            }
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_trabajo, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            finish();//return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @OnClick({R.id.imageView_icono, R.id.button_guardardato})
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.imageView_icono: {
//                Intent i = new Intent(this, GridViewElementImagenes.class);
//                startActivityForResult(i, CARGAR_IMAGEN);
                abrirGalleriaImagenes();

                break;
            }
            case R.id.button_guardardato:{

                Intent intent = new Intent();
                intent.putExtra("dato",dato_editTxt.getText().toString());
                intent.putExtra("icono",nombreDeIcono_TxtView.getText().toString());
                Log.i("<Icono>", "dataelemento: " + nombreDeIcono_TxtView.getText().toString());
                intent.putExtra("precio",precio_editTxt.getText().toString());
                intent.putExtra("numero", numero);

                setResult(2,intent);
                finish();
            }
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        dirImagenes = cw.getDir("imageDir", Context.MODE_PRIVATE);
        // check if the request code is same as what is passed  here it is 2
        if (requestCode == CARGAR_IMAGEN && data != null) {
//            String nombreIcono = data.getStringExtra("MESSAGE");
//            nombreDeIcono_TxtView.setText(nombreIcono);
//
//            Utiles.cargarImg(this, icono_imgView, nombreIcono);
//
//            Log.i("recibido DatoElemento", "recibiendo icono: " + nombreIcono);
            Uri selectedImage = data.getData();
            Log.i("<PATH>", "image path:///////////////////////// ");
            String[] filePathColumn = { MediaStore.Images.Media.DATA };

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);

            String nombreIcono = getImageName(picturePath);
            nombreDeIcono_TxtView.setText(nombreIcono);


            File mypath = new File(dirImagenes, nombreIcono);
            Log.i("<PATH>", "path: absoluto: " + mypath.getPath());
            cargaImagen(picturePath);


            Glide.with(icono_imgView.getContext())
                    .load(picturePath)
                    .apply(new RequestOptions().override(100, 100))
                    .into(icono_imgView);

        }
    }






    public void abrirGalleriaImagenes() {
//            Intent galleryIntent = new Intent(Intent.ACTION_PICK);
//            galleryIntent.setDataAndType(
//                    MediaStore.Images.Media.INTERNAL_CONTENT_URI,
//                    "image/*"
//            );
//
//            galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
//
//            startActivityForResult(
//                    Intent.createChooser(galleryIntent, "Qué aplicación desea utilizar?"),
//                    ACTIVITY_SELECT_IMAGE
//            );

        Intent i = new Intent(
                Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(i, RESULT_LOAD_IMAGE);

    }



    private String getImageName(String picturePath){
        try{
            Integer pos = null;
            if (picturePath != null) {
                pos = picturePath.lastIndexOf("/");
            }
            String name = null;
            if (picturePath != null) {
                name = picturePath.substring(pos + 1);
            }
            if (name != null) {
                pos=name.lastIndexOf(".");
            }
            if (name != null) {
                name=name.substring(0,name.length());
            }
            return name;
        }
        catch (NullPointerException e){
            e.printStackTrace();
            return null;
        }
    }



    private String getImageName(Uri intentUri) {

        final Cursor returnCursor = activity.getContentResolver().query(
                intentUri,
                null,
                null,
                null,
                null
        );
        /*
         * obtiene los indices de las columnas presentes en los datos, y los setea en el Cursor,
         * se mueve a la primera fila en el cursor, obtiene los datos y los muestra.
         */
        assert returnCursor != null;
        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        returnCursor.moveToFirst();

        final String nombreImagen = returnCursor.getString(nameIndex);
        returnCursor.close();

        return nombreImagen;
    }


    protected void cargaImagen(Object imagenRuta) {
        Bitmap imagenBitmap = null;
        String nombreDeImagen = "";

        if (imagenRuta instanceof Uri) {
            imagenBitmap = getImage((Uri) imagenRuta);
            nombreDeImagen = getImageName((Uri) imagenRuta);
            Log.i("<INSTANCIA DE>: ", "[Es un Uri]");

        } else if (imagenRuta instanceof String) {
            imagenBitmap = BitmapFactory.decodeFile((String) imagenRuta);
            nombreDeImagen = getImageName((String) imagenRuta);
            Log.i("<INSTANCIA DE>: ", "[Es un StringPath]");
        }

        if(imagenBitmap != null) {
            File nuevaImagen = new File(dirImagenes, nombreDeImagen);
            Log.i("<PATH>", "nuevaimagen: " + nuevaImagen.getPath());
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(nuevaImagen);
                // Use the compress method on the BitMap object to write image to the OutputStream
                imagenBitmap.compress(
                        Bitmap.CompressFormat.JPEG,
                        100,
                        fileOutputStream
                );
                fileOutputStream.close();
                Log.i("<PATH>", "descomprimiento y seteando");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }



    public Bitmap getImage(Uri uri) {
        Bitmap result = null;
        BitmapFactory.Options options = new BitmapFactory.Options();

        try {
            InputStream is = activity.getContentResolver().openInputStream(uri);
            result = BitmapFactory.decodeStream(is, null, options);
            assert is != null;
            is.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }





}
