package com.example.roberto.editar.models;

/**
 * Created by Roberto on 21/05/2016.
 */
public class ElementsWorksRead {
    Integer _Id;
    Integer WorkRead;
    String Dato;
    String Icono;
    Float Precio;
    Integer Cantidad;
    int posicion;

    public ElementsWorksRead() {
    }

    public ElementsWorksRead(int _id,int workread,String dato,String icono,float precio,int cantidad){
        this._Id=_id;
        this.WorkRead=workread;
        this.Dato=dato;
        this.Icono=icono;
        this.Precio=precio;
        this.Cantidad=cantidad;
    }

    public Integer getCantidad() {
        return Cantidad;
    }

    public void setCantidad(Integer cantidad) {
        Cantidad = cantidad;
    }

    public int getId() {
        return _Id;
    }

    public void setId(int _id) {
        this._Id = _id;
    }

    public int getWorkRead() {
        return WorkRead;
    }

    public void setWorkRead(int workread) {
        this.WorkRead = workread;
    }

    public String getDato() {
        return Dato;
    }

    public void setDato(String dato) {
        this.Dato = dato;
    }

    public String getIcono() {
        return Icono;
    }

    public void setIcono(String icono) {
        this.Icono = icono;
    }

    public float getPrecio() {
        return Precio;
    }

    public void setPrecio(float precio) {
        this.Precio = precio;
    }

    public int getPosicion() {
        return posicion;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }
}

