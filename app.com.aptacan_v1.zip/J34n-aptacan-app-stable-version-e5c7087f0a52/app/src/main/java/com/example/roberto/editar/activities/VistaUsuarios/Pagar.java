package com.example.roberto.editar.activities.VistaUsuarios;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.DbControl;
import com.example.roberto.editar.Utils.Utiles;

import java.util.Locale;

public class Pagar extends AppCompatActivity implements Button.OnClickListener {

    Double total = 0.00;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagar);

        Intent intent = getIntent();
        int idini = intent.getIntExtra("idini", -1);
        int idfin = intent.getIntExtra("idfin", -1);

        CalcularTotal(idini, idfin);
        TextView txt = findViewById(R.id.textView47);
        txt.setText(String.format(Locale.getDefault(), "%.2f", total));

        findViewById(R.id.button16).setOnClickListener(this);
    }


    private void CalcularTotal(int idini, int idfin){
        DbControl dbadapter;
        dbadapter = new DbControl(this);
        dbadapter.open();
        total = dbadapter.TotalaPagar(idini, idfin);
        dbadapter.close();
    }


    @Override
    public void onClick(View v) {
        Intent intento = new Intent(Pagar.this,Pago.class);
        intento.putExtra("Total",total);
        startActivity(intento);
        finish();
    }
}
