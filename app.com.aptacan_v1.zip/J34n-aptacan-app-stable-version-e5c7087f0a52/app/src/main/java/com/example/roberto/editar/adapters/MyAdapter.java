package com.example.roberto.editar.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.roberto.editar.R;
import com.example.roberto.editar.activities.VistaUsuarios.Layout_Trabajo;
import com.example.roberto.editar.models.Works;

import java.util.List;


public class MyAdapter extends RecyclerView.Adapter<FlowerViewHolder> {

    private Context mContext;
    private List<Works> mTrabajoList;

    public MyAdapter(Context mContext, List<Works> mFlowerList) {
        this.mContext = mContext;
        this.mTrabajoList = mFlowerList;
    }

    @NonNull
    @Override
    public FlowerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.trabajo_item, parent, false);
        return new FlowerViewHolder(mView);
    }

    @Override
    public void onBindViewHolder(@NonNull final FlowerViewHolder holder, final int position) {
        String rutaImagen = mTrabajoList.get(holder.getAdapterPosition()).getIconoRuta();
        Boolean existeImagen = !rutaImagen.equals("");

//        if(existeImagen) {
//            Glide.with(holder.mImage.getContext())
//                    .load(rutaImagen)
//                    .into(holder.mImage);
//        } else {
//            Glide.with(holder.mImage.getContext())
//                    .load(R.drawable.noimg)
//                    .into(holder.mImage);
//        }

        Glide.with(holder.mImage.getContext())
                .load(rutaImagen)
                .apply(new RequestOptions().error(R.drawable.noimg))
                .into(holder.mImage);



        holder.mTitle.setText(mTrabajoList.get(holder.getAdapterPosition()).getTitulo());
        holder.mImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(
                        mContext,
                        "trabajo: " + mTrabajoList.get(holder.getAdapterPosition()).getTitulo(),
                        Toast.LENGTH_SHORT
                ).show();

                Intent tarea = new Intent(mContext, Layout_Trabajo.class);
                tarea.putExtra("trabajo", mTrabajoList.get(holder.getAdapterPosition()).getTitulo());
                mContext.startActivity(tarea);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mTrabajoList.size();
    }
}


class FlowerViewHolder extends RecyclerView.ViewHolder {

    ImageView mImage;
    TextView mTitle;
    CardView mCardView;

    FlowerViewHolder(View itemView) {
        super(itemView);

        mImage = itemView.findViewById(R.id.ivImage);
        mTitle = itemView.findViewById(R.id.tvTitle);
        mCardView = itemView.findViewById(R.id.cardview);
    }
}
