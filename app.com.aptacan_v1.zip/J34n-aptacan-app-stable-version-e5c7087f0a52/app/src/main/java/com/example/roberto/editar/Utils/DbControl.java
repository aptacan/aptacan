package com.example.roberto.editar.Utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


public class DbControl extends SQLiteOpenHelper {

    //Ruta por defecto de las bases de datos en el sistema Android
    private static String DB_PATH = "/data/data/com.example.roberto.editar/databases/";

    private static String DB_NAME = "worku.db";

    private SQLiteDatabase myDataBase;

    private final Context myContext;

    /**
     * Constructor
     * Toma referencia hacia el contexto de la aplicación que lo invoca para poder acceder a los 'assets' y 'resources' de la aplicación.
     * Crea un objeto DBOpenHelper que nos permitirá controlar la apertura de la base de datos.
     *
     * @param context
     */
    public DbControl(Context context) {

        super(context, DB_NAME, null, 1);
        this.myContext = context;
    }

    /**
     * Crea una base de datos vacía en el sistema y la reescribe con nuestro fichero de base de datos.
     */
    public void createDataBase() throws IOException {

        boolean dbExist = checkDataBase();

        if (!dbExist) {
        //Llamando a este método se crea la base de datos vacía en la ruta por defecto del sistema
        //de nuestra aplicación por lo que podremos sobreescribirla con nuestra base de datos.
            this.getReadableDatabase();

            try {
                copyDataBase();
            }
            catch (IOException e) {
                throw new Error("Error copiando Base de Datos");
            }
        }
    }

    /**
     * Comprueba si la base de datos existe para evitar copiar siempre el fichero cada vez que se abra la aplicación.
     *
     * @return true si existe, false si no existe
     */
    private boolean checkDataBase() {

        SQLiteDatabase checkDB = null;

        try {
            String myPath = DB_PATH + DB_NAME;
            checkDB = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READONLY);

        } catch (SQLiteException e) {

//si llegamos aqui es porque la base de datos no existe todavía.

        }
        if (checkDB != null) {

            checkDB.close();

        }
        return checkDB != null;
    }

    /**
     * Copia nuestra base de datos desde la carpeta assets a la recién creada
     * base de datos en la carpeta de sistema, desde dónde podremos acceder a ella.
     * Esto se hace con bytestream.
     */
    private void copyDataBase() throws IOException {

//Abrimos el fichero de base de datos como entrada
        InputStream myInput = myContext.getAssets().open(DB_NAME);

//Ruta a la base de datos vacía recién creada
        String outFileName = DB_PATH + DB_NAME;

//Abrimos la base de datos vacía como salida
        OutputStream myOutput = new FileOutputStream(outFileName);

//Transferimos los bytes desde el fichero de entrada al de salida
        byte[] buffer = new byte[1024];
        int length;
        while ((length = myInput.read(buffer)) > 0) {
            myOutput.write(buffer, 0, length);
        }

//Liberamos los streams
        myOutput.flush();
        myOutput.close();
        myInput.close();

    }

    public void open() throws SQLException {

        //Abre la base de datos
        try {
            //copyDataBase();
            createDataBase();
        } catch (IOException e) {
            throw new Error("Ha sido imposible crear la Base de Datos");
        }

        String myPath = DB_PATH + DB_NAME;
        myDataBase = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READWRITE);

    }

    @Override
    public synchronized void close() {
        if (myDataBase != null)
            myDataBase.close();
        super.close();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
/**
 * A continuación se crearán los métodos de lectura, inserción, actualización
 * y borrado de la base de datos.
 * */

    public Cursor allTrabajos(String[] cols){
       try{
        Cursor mcursor=myDataBase.query("Trabajos", cols, null, null, null, null, null);

        if (mcursor != null) {
            mcursor.moveToFirst();
        }
        return mcursor;}
       catch(SQLiteException e){
            return null;
        }

    }

    public Cursor TrabajoporTitulo(String titulo){
        try{
            String query = "Select * from Elementos_Trabajos where Trabajo=(Select distinct _id from trabajos where titulo='" + titulo +"') order by Posición";
            return myDataBase.rawQuery(query, null);
        }
        catch(SQLException e){
            return null;
        }
    }


    public Cursor ElementsofWork(String trabajo){
        try{
            String query = "Select Elementos_Trabajos._Id,Elementos_Trabajos.Elemento,Elementos_Trabajos.Trabajo,Elementos.Nombre,Elementos_Trabajos.Posición, Count(Datos.Dato) as Datos," +
            "(Select Datos.Dato from Datos where _Id in (select MIN(_Id) from datos  Group by Elemento,Trabajo) " +
            "and Elementos_Trabajos._Id=Datos.Elemento and Elementos_Trabajos.Trabajo=Datos.Trabajo " +
            "Group by elemento,trabajo)  as Prompt " +
            "from Elementos_Trabajos,datos,Elementos "+
            "where Elementos_Trabajos._Id=Datos.Elemento and Elementos_Trabajos.Trabajo=Datos.Trabajo " +
            "and Elementos_Trabajos.Elemento=Elementos._Id and Elementos_Trabajos.Trabajo=" + trabajo + " " +
            "Group by Elementos_Trabajos._Id,Elementos_Trabajos.Elemento " +
            "Order by Posición";
            Cursor mcursor=myDataBase.rawQuery(query, null);

            if (mcursor != null) {
                mcursor.moveToFirst();
            }
            return mcursor;

        } catch(SQLiteException e) {
            return null;
        }
    }



    public void removework(String _id) {
        myDataBase.delete("Trabajos", "_Id = " + _id, null);
    }

    public void updateWork(String id,String titulo,Double precio,String icono) {
        String[] args = new String[]{id};
        ContentValues values= new ContentValues();
        values.put("titulo",titulo);
        values.put("precio",precio);
        values.put("icono",icono);
        myDataBase.update("Trabajos", values, "_Id=?", args);
    }

    public void insertWork(String titulo, Double precio,String icono) {
        //Creamos el registro a insertar como objeto ContentValues
        ContentValues nuevoRegistro = new ContentValues();
        nuevoRegistro.put("titulo", titulo);
        nuevoRegistro.put("precio",precio);
        nuevoRegistro.put("icono",icono);

        //Insertamos el registro en la base de datos
        myDataBase.insert("Trabajos", null, nuevoRegistro);
    }

    public int maxposicion(String trabajo){
        String query="Select max(posición) from Elementos_Trabajos where Trabajo="+trabajo;
        Cursor mcursor=myDataBase.rawQuery(query, null);
        if (mcursor != null) {
            mcursor.moveToFirst();
        }
        return mcursor.getInt(0);
    }

    public int maxelemento(String trabajo){
        String query="Select max(_Id) from Elementos_Trabajos where Trabajo="+trabajo;
        Cursor mcursor=myDataBase.rawQuery(query, null);
        if (mcursor != null) {
            mcursor.moveToFirst();
        }
        return mcursor.getInt(0);
    }

    public Cursor obtenerdatos(String et,String trabajo){
        String query="Select Dato,Icono,Precio from Datos where Trabajo=" + trabajo + " and Elemento="+ et;
        Cursor mcursor=myDataBase.rawQuery(query,null);
        if (mcursor != null) {
            mcursor.moveToFirst();
        }
        return mcursor;
    }

    public List<String> obtenerdatosspinner(String et,String trabajo){
        List<String> labels = new ArrayList<String>();
        String query="Select Dato from Datos where Trabajo=" + trabajo + " and Elemento="+ et + " and _Id<>(Select min(_Id) from Datos where Trabajo=" + trabajo + " and Elemento="+ et +")";
        Cursor mcursor=myDataBase.rawQuery(query,null);
        if (mcursor.moveToFirst()) {
            do {
                labels.add(mcursor.getString(0));
            } while (mcursor.moveToNext());
        }
        mcursor.close();
        return labels;
    }

    public String trabajo(String trabajo){
        String query="Select titulo from Trabajos where _id=" + trabajo;
        Cursor mcursor=myDataBase.rawQuery(query, null);
        if (mcursor != null) {
            mcursor.moveToFirst();
        }
        String titulo=mcursor.getString(0);
        return titulo;
    }

    public Integer Actualizar(String Table,ContentValues Cambios,String Condicion,String[] Args){
        Integer cambios=myDataBase.update(Table, Cambios, Condicion, Args);
        return cambios;
    }

    public void Actualizarpos(String etid,String trabajo,String argumento,String actualizacion){
        String query="Update Elementos_Trabajos " +
                "set Posición=Posición" + actualizacion +
                " where " + argumento + " and _Id<>" + etid + " and Trabajo=" + trabajo;
        myDataBase.execSQL(query);
    }

    public void eliminarelemento(String etid){
        String query="Delete from Elementos_Trabajos Where _Id =" + etid;

        myDataBase.execSQL(query);
    }


    public Long Insertar(String Table,ContentValues valores){
        long cambios=myDataBase.insert(Table, null, valores);
        return cambios;
    }

    public void EliminarDatos(Integer datos, String et, String trabajo){
        String query="Delete from Datos Where _Id in " +
                "(Select _Id from Datos Where Elemento=" + et + " and Trabajo=" + trabajo + " Order by _Id Desc limit "+datos.toString()+" )";
        myDataBase.execSQL(query);
    }

    public Integer[] Idsdatos(String et,String trabajo){
        String query="Select _Id from Datos where Trabajo=" + trabajo + " and Elemento=" + et;
        Cursor mcursor=myDataBase.rawQuery(query,null);
        Integer[] datos=new Integer[mcursor.getCount()];
        if (mcursor != null){
            mcursor.moveToFirst();
        }
        Integer i=0;
        do {
            datos[i] = mcursor.getInt(0);
            i++;
        }while(mcursor.moveToNext());
        return datos;
    }

    public Cursor DatosWorkRead(String Titulo){
        String[] args = new String[] { Titulo };
        Cursor mcursor = myDataBase.query("Trabajos", null, "titulo=?", args, null, null, null);
        if (mcursor != null){
            mcursor.moveToFirst();
        }
        return mcursor;
    }

    public Cursor ConsultaWorkReads(Integer idini, Integer idfin){
        Cursor mcursor=myDataBase.query(
                "WorksRead",
                null,
                "_Id between ? and ?",
                new String[]{ idini.toString(),  idfin.toString() },
                null,
                null,
                null
        );

        if (mcursor != null){
            mcursor.moveToFirst();
        }
        return mcursor;
    }

    public Cursor ConsultaElementsWorkReads(Integer id){
        String[] args = new String[] {String.format(Locale.getDefault(),"%d",id)};
        Cursor mcursor=myDataBase.query("ElementsWorkRead",null,"_Id_WorkRead=?",args,null,null,null);
        if (mcursor != null){
            mcursor.moveToFirst();
        }
        return mcursor;
    }

    public Integer EstaImagen(String imagen){
        Integer repeticiones=0;
        String consulta="SELECT SUM(num) as totalnum from " +
                "(SELECT COUNT(*) as num FROM Datos where Datos.Icono='" + imagen +"' " +
                "union " +
                "SELECT COUNT(*) as num FROM Trabajos where Trabajos.icono='" + imagen +"') as tavla";
        Cursor mcursor=myDataBase.rawQuery(consulta,null);
        mcursor.moveToFirst();
        repeticiones=mcursor.getInt(0);
        return repeticiones;
    }

    public void Eliminar(String tabla, String where, String[] Args){
        myDataBase.delete(tabla,where,Args);
    }

    //calculo de los items elegidos de un trabajo
    public Double TotalaPagar(int idini,int idfin){
        double total=0.00;
        double cantidad=1;
//        precios0.precio+ //se eliminó para poder duplicar el valor en caso de doble cara seleccionado
        String consulta = "SELECT SUM((precios0.precio) * cantidades.cantidad) from " +
                "(SELECT sum(Precio) as precio, _Id_WorkRead as id FROM ElementsWorkRead where _Id_WorkRead between " + idini + " and " + idfin + " group by _Id_WorkRead) as precios0, " +
                "(SELECT Precio as precio, _Id as id FROM WorksRead where _Id between "+idini+" and "+idfin+" ) as precios1, "+
                "(select sum(cantidad) as cantidad, _Id_WorkRead as id from elementsworkread  where _id_workread between " + idini + " and " + idfin + " group by _Id_WorkRead) as cantidades " +
                "where precios0.id=precios1.id and cantidades.id=precios0.id";



        Cursor mcursor=myDataBase.rawQuery(consulta,null);
        mcursor.moveToFirst();
        total = mcursor.getFloat(0);

        return total;
    }

    public Double TotalaPagar(int idTrabajo, int idini,int idfin){
        double total=0.00;
        double cantidad=1;
//        precios0.precio+
        String consulta="SELECT SUM(precios0.precio * cantidades.cantidad) from " +
                "(SELECT sum(Precio) as precio, _Id_WorkRead as id FROM ElementsWorkRead where _Id_WorkRead between " + idini + " and " + idfin + " group by _Id_WorkRead) as precios0, " +
                "(SELECT Precio as precio, _Id as id FROM WorksRead where _Id between "+idini+" and "+idfin+" ) as precios1, "+
                "(SELECT sum(Dato) as cantidad, _Id_workRead as id FROM ElementsWorkRead where _Id_WorkRead between "+idini+" and "+idfin+" group by _Id_WorkRead) as cantidades"+
                " where precios0.id=precios1.id and cantidades.id=precios0.id";
        Cursor mcursor=myDataBase.rawQuery(consulta,null);
        mcursor.moveToFirst();
        total = mcursor.getFloat(0);

        return total;
    }



    public void BorrarTrabajos() {
        String query="Delete from WorksRead";
        myDataBase.execSQL(query);
        query="Delete from ElementsWorkRead";
        myDataBase.execSQL(query);
    }

    public int getMaxIdfromWorksRead() {
        String consulta = "SELECT max(_Id) from WorksRead";
        Cursor mcursor = myDataBase.rawQuery(consulta,null);
        if (mcursor.moveToFirst()) {
            return mcursor.getInt(0);
        }
        return 0;
    }
}
