package com.example.roberto.editar.adapters;

import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.roberto.editar.R;
import com.example.roberto.editar.models.ElementsWorksRead;
import com.example.roberto.editar.models.Rango;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

public class ArticuloRecyclerAdapter extends RecyclerView.Adapter<ArticuloRecyclerAdapter.ArticulosViewHolder> {

    private static final int NO_HAY_ELEMENTOS = 0;
    private static final int ULTIMO_ELEMENTO = 0;

    private int cantidadDeArticulos;
    private ArrayList<ElementsWorksRead> elementos;
    private int cantidad;
    private String icono;
    private Context contexto;
    private Rango rango;
    private View.OnClickListener listenerActivity;



    public ArticuloRecyclerAdapter(ElementsWorksRead[] elementos, int cantidadDeArticulos, Context contexto, View.OnClickListener listenerActivity) {
        this.elementos = new ArrayList<ElementsWorksRead>(Arrays.asList(elementos)); ;
        this.contexto = contexto;
        this.listenerActivity = listenerActivity;

//        //para cuando solo se setean las entradas numericas
//        if (elementos.length > 1) {
//            this.icono = elementos[1].getIcono();
//        } else {
            this.icono = elementos[0].getIcono();
//        }


        rango = new Rango(elementos[0].getDato());
        Log.i("Probando Rango: ", "inicio: " + rango.getInicio() + "fin:" + rango.getFin() + "cantidad: " + rango.getCantidad());

        this.cantidad = rango.getCantidad();
        setPosiciones(rango.getInicio(), rango.getFin());
    }


    private void setPosiciones(int inicio, int fin) {
        ElementsWorksRead elementsWorksRead = elementos.get(0);
//        ArrayList<ElementsWorksRead> elementsWorksReads = new ArrayList<>()
        int size = cantidad;

        elementos.clear();
        for (int i = inicio; i <= fin; i++) {
            ElementsWorksRead element = new ElementsWorksRead();
            element.setPosicion(i);
            elementos.add(element);
        }
    }




    @NonNull
    @Override
    public ArticulosViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cardview_articulo, parent, false);


        return new ArticulosViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ArticulosViewHolder articulosViewHolder, final int posicion) {
        final ElementsWorksRead elemento = elementos.get(posicion);




                Log.i("[RECYCLER]: ", "elemento icono --> " + elemento.getIcono());
        String posicionStr = String.valueOf(elemento.getPosicion());

        articulosViewHolder.articuloNumero.setText(posicionStr);
        Glide.with(contexto)
                .load(elemento.getIcono())
                .apply(
                        new RequestOptions().override(100, 100)
                                .error(R.drawable.img_pagina) )
                .into(articulosViewHolder.articuloImagen);

        Log.i("DesdeRecyclerArticulo", " icono ruta: " + elemento.getIcono());
//
        if(posicion == ULTIMO_ELEMENTO) {
            articulosViewHolder.articuloNumero.setBackgroundColor(Color.MAGENTA);
            articulosViewHolder.articuloNumero.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        }


        articulosViewHolder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(posicion == ULTIMO_ELEMENTO) {
                    Log.i("TESTEANDO....", "posicion: " + posicion);
                    elementos.remove(posicion);
//                    Toast.makeText(contexto.getApplicationContext(), "PERFECTO!", Toast.LENGTH_SHORT).show();
                    notifyDataSetChanged();
                    notifyItemRemoved(posicion);
                }


                //ir a la siguiente iteraccion en las indicaciones
                if(getItemCount() == NO_HAY_ELEMENTOS) {
                    listenerActivity.onClick(v);
                    Log.i("recycler", "-------------->");
                }

                if(elemento.getPosicion() == rango.getFin()) {
                    Toast.makeText(contexto.getApplicationContext(), "PERFECTO!", Toast.LENGTH_SHORT).show();
                }
            }
        });





//        articulosViewHolder.articuloImagen.setBackground(contexto.getDrawable(R.drawable.sunflower));

        cargarImagen(icono, articulosViewHolder.articuloImagen);
    }

    @Override
    public int getItemCount() {
        return elementos.size();
    }



    private void cargarImagen(String icono,ImageView imageView) {

        ContextWrapper cw = new ContextWrapper(contexto);

        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        File archivoImagen = new File(directory, icono);

        if (archivoImagen.exists()) {
            Glide.with(contexto)
                    .load(archivoImagen.getPath())
                    .apply(new RequestOptions().fitCenter())
                    .into(imageView);
        }
    }




















    class ArticulosViewHolder extends RecyclerView.ViewHolder{

        private ImageView articuloImagen;
        private CardView cardView;
        private TextView articuloNumero;

        ArticulosViewHolder(View itemView) {
            super(itemView);

            articuloImagen  = itemView.findViewById(R.id.articulo_imageView);
            cardView       = itemView.findViewById(R.id.articulos_cardview);
            articuloNumero = itemView.findViewById(R.id.articulo_numero_textview);

        }
    }
}
