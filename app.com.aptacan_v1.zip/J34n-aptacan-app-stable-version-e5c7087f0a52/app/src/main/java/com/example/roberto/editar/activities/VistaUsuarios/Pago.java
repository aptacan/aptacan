package com.example.roberto.editar.activities.VistaUsuarios;

import android.annotation.TargetApi;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.Utiles;

import java.util.HashMap;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class Pago extends AppCompatActivity implements TextToSpeech.OnInitListener{

    private double dineroAPagar = 0.00;
    private int centavosAPagar = 0;
    private SharedPreferences preferencias;
    TextToSpeech hablador;
    MediaPlayer mMediaPlayer;
    private Boolean sonidoMonedaCompletado = false;
    private int valorId;
    private Intent irActivity;


    private boolean irAResultadoActivity = false;

    @BindView(R.id.totalpago) public TextView totalPagar_txtView;
    @BindView(R.id.textView25) public TextView dineroACancelar_txtView;


    final double[] valoresMoneda = {0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50};

    final static int[] imageButtons = {
            R.id.imageButton25, R.id.imageButton26, R.id.imageButton27, R.id.imageButton28,
            R.id.imageButton29, R.id.imageButton30, R.id.imageButton31, R.id.imageButton32,
            R.id.imageButton33, R.id.imageButton34, R.id.imageButton35, R.id.imageButton36
    };

    final static int[] imagenes = {
            R.drawable.uncent, R.drawable.doscent, R.drawable.cincocent, R.drawable.diezcent,
            R.drawable.veintecent, R.drawable.cincuentacent, R.drawable.uneuro, R.drawable.doseuro,
            R.drawable.cincoeuro, R.drawable.diezeuro, R.drawable.veinteeuro, R.drawable.cincuentaeuro
    };

    final String[] palabras = new String[] {
            "un céntimo", "dos céntimos", "cinco céntimos", "diez céntimos",
            "veinte céntimos", "cincuenta céntimos", "un euro", "dos euros",
            "cinco euros", "diez euros", "veinte euros", "cincuenta euros"
    };

    final String[] valoresMonedaXml = new String[] {
            "uncent", "doscent", "cincocent", "diezcent",
            "veintecent", "cincuentacent", "uneuro", "doseuros",
            "cincoeuros", "diezeuros", "veinteeuros", "cincunetaeuros"
    };






    @OnClick({
            R.id.imageButton25, R.id.imageButton26, R.id.imageButton27, R.id.imageButton28,
            R.id.imageButton29, R.id.imageButton30, R.id.imageButton31, R.id.imageButton32,
            R.id.imageButton33, R.id.imageButton34, R.id.imageButton35, R.id.imageButton36
    })
    public void onClick(View v) {
//        if(mMediaPlayer.isPlaying()) {
//            mMediaPlayer.pause();
//        } else {
            mMediaPlayer.start();
//            sonidoMonedaCompletado = false;
//        }
        Integer valorId = -1;
        switch (v.getId()) {
            case R.id.imageButton25: valorId = 0; break;
            case R.id.imageButton26: valorId = 1; break;
            case R.id.imageButton27: valorId = 2; break;
            case R.id.imageButton28: valorId = 3; break;
            case R.id.imageButton29: valorId = 4; break;
            case R.id.imageButton30: valorId = 5; break;
            case R.id.imageButton31: valorId = 6; break;
            case R.id.imageButton32: valorId = 7; break;
            case R.id.imageButton33: valorId = 8; break;
            case R.id.imageButton34: valorId = 9; break;
            case R.id.imageButton35: valorId = 10; break;
            case R.id.imageButton36: valorId = 11; break;
            default: break;
        }
        this.valorId = valorId;
//        disminuirDineroAPagar(valorId);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_pago);
        ButterKnife.bind(this);

        hablador = new TextToSpeech(this,this);
        preferencias = getSharedPreferences("Monedero", MODE_PRIVATE);

        Intent intent = getIntent();

        if(intent.getExtras() != null) {

            double totalPagar = intent.getExtras().getDouble("Total");
            Log.i("<OBTENIDO>", "valor totla: " + totalPagar);

            totalPagar_txtView.setText( String.format(
                    Locale.getDefault(),
                    "%.2f",
                    totalPagar
            ));
            dineroACancelar_txtView.setText( String.format(
                    Locale.getDefault(),
                    "%.2f",
                    totalPagar
            ));
            dineroAPagar = totalPagar;
            centavosAPagar =(int)(Utiles.round(dineroAPagar,2) *100);

        } else {
            Log.i("<NULL OBJECT>: ", "intent.getExtras() --> (NULL)");
        }

        int[] medidas = Utiles.medirPantalla(this);
        cargarImagenesEnPantalla(240, 120);
//        Tablero tablero = new Tablero();
//        ArrayList<Moneda> monedas = tablero.arrayToMonedas(
//                valoresMoneda,
//                palabras,
//                imageButtons,
//                imagenes
//        );
//        tablero.cargarImagenes(
//                this,
//                medidas[0],
//                medidas[1],
//                monedas
//        );

        mMediaPlayer = MediaPlayer.create(this, R.raw.sonido_monedas);
        mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Log.i("<ESTADO DEL SONIDO>", "SONIDO MONEDA COMPLETADO");
                disminuirDineroAPagar(valorId);
                evaluarVuelta();
            }
        });



        hablador.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {

                Log.i("TTS ", "comenzando a hablar....");
            }

            @Override
            public void onDone(String utteranceId) {
                Log.i("TTS ", "abrir nueva actividad");

                if(!hablador.isSpeaking())
                    hablador.stop();
            }

            @Override
            public void onError(String utteranceId) {
                Log.i("TTS", "ha ocurrido un error");
            }
        });
    }



    private void cargarImagenesEnPantalla(int x , int y) {
        int size = imageButtons.length;
        for (int i = 0; i < size; i++) {
            ImageView image = findViewById(imageButtons[i]);
            Glide.with(this)
                    .load(imagenes[i])
                    .apply(new RequestOptions().override(x, y))
                    .into(image);
        }
    }



    private void disminuirDineroAPagar(int valorPagadoId) {

        hablar("Me das " + palabras[valorPagadoId], "medas", TextToSpeech.QUEUE_FLUSH);

        double valorPagado = valoresMoneda[valorPagadoId];
        dineroAPagar = Utiles.round(dineroAPagar -  valorPagado,2);
        centavosAPagar = centavosAPagar - (int)(valorPagado * 100);

        Log.i("<Disminuir Method>: ", "centavosApagar: " + centavosAPagar + "\tdineroPAgr: " + dineroAPagar);

        String dineroApagar_str = String.format(
                Locale.getDefault(),
                "%.2f Euros",
                 dineroAPagar
        );
        dineroACancelar_txtView.setText(dineroApagar_str);

        SharedPreferences.Editor editor = this.preferencias.edit();
        editor.putInt(
                valoresMonedaXml[valorPagadoId],
                this.preferencias.getInt(valoresMonedaXml[valorPagadoId], 0) + 1
        );
        editor.apply();

//        if(!hablador.isSpeaking())
//            evaluarVuelta();


//        /*if ("0.00".equals(String.format("%.2f",dineroAPagar))){
//            Intent intento = new Intent(Pago.this,Despedir.class);
//            startActivity(intento);
//        }else if (dineroAPagar<0){
//            Intent intento = new Intent(Pago.this,vueltas.class);
//            intento.putExtra("Vuelta",dineroAPagar*-1);
//            startActivity(intento);
//        }*/
    }



    private void evaluarVuelta() {

        if (this.centavosAPagar == 0) {
            irAResultadoActivity = true;
            Intent intent = new Intent(Pago.this, Despedir.class);
            irActivity = intent;
            hablador.stop();
            startActivity(irActivity);
//            finish();

        } else if (this.centavosAPagar < 0){
            irAResultadoActivity = true;
            Intent intent = new Intent(Pago.this, vueltas.class);
            intent.putExtra("Vuelta",this.dineroAPagar * (-1) );
            irActivity = intent;
            hablador.stop();
            startActivity(irActivity);
//            finish();

        } else {
            irAResultadoActivity = false;
            int euros = (centavosAPagar / 100);
            int centimos = centavosAPagar - (euros * 100);

            String msgDineroFaltante = getMsgDineroFaltante(euros, centimos);

            Log.i("<MENSAJE HABLADO>", "Mensaje: " + msgDineroFaltante);
            Log.i("<DINERO FALTA>", "cantidaad: " + centavosAPagar + "\t euros: " + euros + "     centimos: " + centimos);
            hablar(msgDineroFaltante,"falta", TextToSpeech.QUEUE_ADD);
        }
    }



    //Faltan (x) euros y (x) centimos
    private String getMsgDineroFaltante(final int euros, final int centimos) {
        String mensaje = "Faltan ";

        if(euros == 1)
            mensaje +=  " un euro";
        else if (euros > 1)
            mensaje +=  euros + " euros";

        if(euros != 0 && centimos != 0)
            mensaje += " y ";

        if(centimos == 1)
            mensaje += " un " + "céntimo";
        else if(centimos > 1)
            mensaje += " " + centimos + " céntimos";

        return mensaje;
    }

//68,


    /**
     * Called to signal the completion of the TextToSpeech engine initialization.
     *
     * @param status {@link TextToSpeech#SUCCESS} or {@link TextToSpeech#ERROR}.
     */
    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            hablador.setLanguage(new Locale("spa", "MEX"));
        }
    }



    public void hablar(String text, String utteranceId, int mode) {
            if (hablador != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    ttsApi21superiores(text, utteranceId, mode);
                } else {
                    ttsApi20inferiores(text, mode);
                }
            }
    }

//    @Override
//    protected void onDestroy() {
//
//        if(this.hablador != null) {
//
//            hablador.stop();
//            hablador.shutdown();
//            Log.d("<PAGO>", " estado: TTS Destroyed");
//        }
//
//        super.onDestroy();
//    }

    private void ttsApi20inferiores(String text, int mode) {
        HashMap<String, String> map = new HashMap<>();
        map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "MessageId");
        hablador.speak(text, mode, map);
    }



    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private void ttsApi21superiores(String text, String utteranceId, int mode) {
//        String utteranceId = this.hashCode() + "";
        hablador.speak(text, mode, null, utteranceId);
    }



//    @Override
//    public void onUtteranceCompleted(String utteranceId) {
////        hablador.stop();
//    }
}
