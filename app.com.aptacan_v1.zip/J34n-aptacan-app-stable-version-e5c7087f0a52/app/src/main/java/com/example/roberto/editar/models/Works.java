package com.example.roberto.editar.models;

/**
 * Created by Roberto on 29/07/2015.
 */
public class Works {
    int id = 0;
    String titulo = "";
    String icono = "";
    double precio= 0.05;
    String iconoRuta;

    public Works(int id, String titulo, String icono, double precio) {
        this.id=id;
        this.titulo=titulo;
        this.icono=icono;
        this.precio=precio;
    }


    public Works(int id, String titulo, String icono, double precio, String iconoRuta) {
        this.id = id;
        this.titulo = titulo;
        this.icono = icono;
        this.precio = precio;
        this.iconoRuta = iconoRuta;
    }


    public String getIconoRuta() {
        return iconoRuta;
    }

    public void setIconoRuta(String iconoRuta) {
        this.iconoRuta = iconoRuta;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getIcono() {
        return icono;
    }

    public void setIcono(String icono) {
        this.icono = icono;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

}
