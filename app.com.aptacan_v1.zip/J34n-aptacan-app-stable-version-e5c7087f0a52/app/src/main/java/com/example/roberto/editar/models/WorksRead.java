package com.example.roberto.editar.models;

/**
 * Created by Roberto on 21/05/2016.
 */
public class WorksRead {
    int id = 0;
    String titulo;
    String icono;
    double precio;

    public WorksRead(int id, String titulo, String icono, double precio) {
        this.id = id;
        this.titulo=titulo;
        this.icono=icono;
        this.precio=precio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getIcono() {
        return icono;
    }

    public void setIcono(String icono) {
        this.icono = icono;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
}
