package com.example.roberto.editar.models;

public class Pagina {
    public int numeroPagina;
    public int ImgButtonID;
    public int ImgDrawableID;

    public Pagina(int numeroPagina, int imgButtonID, int imgDrawableID) {
        this.numeroPagina = numeroPagina;
        ImgButtonID = imgButtonID;
        ImgDrawableID = imgDrawableID;
    }

    public Pagina(int imgButtonID, int imgDrawableID) {
        this.ImgButtonID = imgButtonID;
        this.ImgDrawableID = imgDrawableID;
    }
}
