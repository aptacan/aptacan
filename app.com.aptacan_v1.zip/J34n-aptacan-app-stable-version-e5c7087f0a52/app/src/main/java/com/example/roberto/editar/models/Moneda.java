package com.example.roberto.editar.models;


public final class Moneda extends Pagina{

    public float valor;
    public String nombre;



    public Moneda(int numeroPagina,  float valor, String nombre, int imgViewID, int imgDrawableID) {
        super(numeroPagina, imgViewID, imgDrawableID);
        this.valor = valor;
        this.nombre = nombre;
    }

    public Moneda(float valor, String nombre, int imgViewID, int imgDrawableID) {
        super(imgViewID, imgDrawableID);
        this.valor = valor;
        this.nombre = nombre;
    }
}




