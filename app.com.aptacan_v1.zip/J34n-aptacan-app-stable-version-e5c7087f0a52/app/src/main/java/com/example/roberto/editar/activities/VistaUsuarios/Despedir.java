package com.example.roberto.editar.activities.VistaUsuarios;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.roberto.editar.MainActivity;
import com.example.roberto.editar.R;

public class Despedir extends AppCompatActivity implements Button.OnClickListener{
//private DbControl base;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_despedir);
        findViewById(R.id.button13).setOnClickListener(this);
/*        base = new DbControl(this);
        base.open();*/

        int time = 7;
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(Despedir.this, Menu_Trabajos.class);
                startActivity(intent);
                finish();
            }
        }, time * 1000);

    }

    @Override
    public void onClick(View v) {
        Intent intento=new Intent(Despedir.this, MainActivity.class);
        startActivity(intento);
///*     base.BorrarTrabajos();*/


//        if (getIntent().getIntExtra("Time", 0) > 0) {
//            int time = getIntent().getIntExtra("Time" , 0);

//        }
    }
}
