package com.example.roberto.editar.models;

/**
 * Created by Roberto on 20/09/2015.
 */
public class ElementsWorks {
    private Integer _Id;
    private Integer Elemento;
    private Integer Trabajo;
    private String ENombre;
    private Integer Posicion;
    private Integer Datos;
    private String Prompt; 

    public ElementsWorks(int _id,int elemento,int trabajo,String enombre,int posicion,int datos,String prompt){
        this._Id=_id;
        this.Elemento=elemento;
        this.Trabajo=trabajo;
        this.ENombre=enombre;
        this.Prompt=prompt;
        this.Posicion=posicion;
        this.Datos=datos;
    }

    public int getId() {
        return _Id;
    }

    public void setId(int _id) {
        this.Elemento = _id;
    }

    public int getElemento() {
        return Elemento;
    }

    public void setElemento(int elemento) {
        this.Elemento = elemento;
    }

    public int getTrabajo() {
        return Trabajo;
    }

    public void setTrabajo(int trabajo) {
        this.Trabajo = trabajo;
    }

    public String getENombre() {
        return ENombre;
    }

    public void setENombre(String enombre) {
        this.ENombre = enombre;
    }

    public String getPrompt() {
        return Prompt;
    }

    public void setPrompt(String prompt) {
        this.Prompt = prompt;
    }

    public int getPosicion() {
        return Posicion;
    }

    public void setPosicion(int posicion) {
        this.Posicion = posicion;
    }

    public int getDatos() {
        return Datos;
    }

    public void setDatos(int datos) {
        this.Datos = datos;
    }

}
