package com.example.roberto.editar.activities.VistaUsuarios;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.database.Cursor;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TableLayout;
import android.widget.Toast;

import com.example.roberto.editar.Utils.Eudex;
import com.example.roberto.editar.R;
import com.example.roberto.editar.Utils.DbControl;

import java.io.File;
import java.util.ArrayList;
import java.util.Locale;

import com.example.roberto.editar.adapters.MyAdapter;
import com.example.roberto.editar.models.Works;


import static android.speech.SpeechRecognizer.createSpeechRecognizer;

public class Menu_Trabajos extends AppCompatActivity{

    private static final String LOGTAG = "LogsAndroid";
    private DbControl db;
    private ArrayList<String> listaTrabajos;
    private String mDirectorioImagen;


    final static int COMANDOS_PORVOZ_ID = 104;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_trabajo_items);
        RecyclerView mRecyclerView = findViewById(R.id.recyclerview);
        GridLayoutManager mGridLayoutManager = new GridLayoutManager(Menu_Trabajos.this, 2);
        mRecyclerView.setLayoutManager(mGridLayoutManager);

        mDirectorioImagen = this.getRutaDirImagenes();
        db = new DbControl(this);
        ArrayList<Works> mTrabajos = this.getTrabajos();

        MyAdapter myAdapter = new MyAdapter(Menu_Trabajos.this, mTrabajos);
        mRecyclerView.setAdapter(myAdapter);
//
//        myTableLayout = new TableLayout (this);
//        myTableLayout.removeAllViewsInLayout();
//        db =new DbControl(this);
//        drawScreen();




//        reconocerVoz("¿Qué trabajo deseas?");
//        // Otra forma de implementar Reconocimiento de voz
//        Context baseContext = this.getBaseContext();
//        SpeechRecognizer recon = createSpeechRecognizer(baseContext);
//
//        recon.setRecognitionListener(new RecognitionListener() {
//            @Override
//            public void onReadyForSpeech(Bundle params) {
//
//            }
//
//            @Override
//            public void onBeginningOfSpeech() {
//
//            }
//
//            @Override
//            public void onRmsChanged(float rmsdB) {
//
//            }
//
//            @Override
//            public void onBufferReceived(byte[] buffer) {
//
//            }
//
//            @Override
//            public void onEndOfSpeech() {
//
//            }
//
//            @Override
//            public void onError(int error) {
//
//            }
//
//            @Override
//            public void onResults(Bundle results) {
//
//            }
//
//            @Override
//            public void onPartialResults(Bundle partialResults) {
//
//            }
//
//            @Override
//            public void onEvent(int eventType, Bundle params) {
//
//            }
//        });
//        recon.startListening(new Intent());
    }



    protected void reconocerVoz(String peticionAlUsuario) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

        intent.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        );

        intent.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE,
                Locale.getDefault()
        );

        intent.putExtra(
                RecognizerIntent.EXTRA_PROMPT,
                peticionAlUsuario
        );

        if(intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, COMANDOS_PORVOZ_ID);
        } else {
            Toast.makeText(
                    this,
                    "[Comandos por Voz] no soportado por Dispositivo.",
                    Toast.LENGTH_LONG ).show();
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_trabajo, menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            finish();//return true;
        }

        return super.onOptionsItemSelected(item);
    }



//remplazar con metodos que no habran imagenes sino que solo guarden URI o FILE.
    private String getRutaDirImagenes() {
        ContextWrapper contextWrapper = new ContextWrapper(getApplicationContext());
        File directorioImagenes = contextWrapper.getDir("imageDir", Context.MODE_PRIVATE);
        if(directorioImagenes.exists()) {
            return directorioImagenes.toString();
        }
        return "";
    }



    private String getRutaImg(String Icono) {
        if (!Icono.equals("")) {
            return this.mDirectorioImagen + "/" + Icono; //ruta de imagen
        }
        return "";
    }
//    public void go(View v) {
//        Button button = (Button) v;
//        String trabajo = button.getText().toString();
//
//        lanzarTrabajo(trabajo);
//    }

//    private TableRow Rowadd(){
//        TableRow buttonRow = new TableRow(myTableLayout.getContext());
//
//        TableLayout.LayoutParams pRowTop = new TableLayout.LayoutParams(
//                TableLayout.LayoutParams.MATCH_PARENT,
//                TableLayout.LayoutParams.MATCH_PARENT
//        );
//        pRowTop.weight = 1;
//        buttonRow.setGravity(Gravity.CENTER);
//        myTableLayout.addView(buttonRow,pRowTop);
//
//        return buttonRow;
//    }

//    private void Buttonadd(TableRow tr,String titulo, String icono){
//        Button buttonnew = new Button(this);
//        buttonnew.setText(titulo);
//
//        if(!icono.equals("")) {
//            ContextWrapper contextWrapper = new ContextWrapper(getApplicationContext());
//                  File directorioImagenes = contextWrapper.getDir("imageDir", Context.MODE_PRIVATE);
//                        String rutaImagen = directorioImagenes.toString() + "/" + icono;
//                              File imagen = new File(rutaImagen);
//
//            Drawable imagenDrawable = null;
//
//            if(imagen.exists()) {
//                imagenDrawable = Drawable.createFromPath(rutaImagen);
//
//                imagenDrawable.setBounds(
//                        0,
//                        0,
//                        150,
//                        150
//                );
//                buttonnew.setCompoundDrawablesRelative(null, imagenDrawable, null, null);
//                buttonnew.setPadding(50, 70, 50, 50);
//            }
//        }
//
//        TableRow.LayoutParams pButton = new TableRow.LayoutParams(
//                TableRow.LayoutParams.MATCH_PARENT,
//                TableRow.LayoutParams.WRAP_CONTENT
//        );
//        pButton.weight = 1;
//
//        Button.OnClickListener listener = new Button.OnClickListener() {
//
//            @Override
//            public void onClick(View view) {
//                go(view);
//            }
//        };
//        buttonnew.setOnClickListener(listener);
//
//        tr.addView(buttonnew, pButton);
//    }
//    private void drawScreen() {
//        listaTrabajos = new ArrayList<String>(20);
//        TableRow tableRow;
//        ArrayList<Works> trabajos = getTrabajos();
//        tableRow = null;
//
//        for(int i = 0 ; i < trabajos.size() ; i++) {
//            if ( i%3 == 0)
//                tableRow = Rowadd();
//
//            Buttonadd(
//                    tableRow,
//                    trabajos.get(i).getTitulo(),
//                    trabajos.get(i).getIcono()
//            );
//            listaTrabajos.add(trabajos.get(i).getTitulo());
//        }
//        setContentView(myTableLayout);
//    }



    private ArrayList<Works> getTrabajos() {

        ArrayList<Works> lista = new ArrayList<>();

        // Columnas de la tabla trabajos
          String KEY_ID = "_id";
        String KEY_COL1 = "titulo";
        String KEY_COL2 = "icono";
        String KEY_COL3 = "precio";

        //Array de strings para su uso en los diferentes métodos
        String[] columnas = new String[] { KEY_ID, KEY_COL1, KEY_COL2, KEY_COL3 };
        db.open();
        Cursor cursor = db.allTrabajos(columnas);

        if (cursor.moveToFirst()) {
            do {
                Works trabajo = new Works(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getDouble(3)
                );
                trabajo.setIconoRuta(this.getRutaImg(trabajo.getIcono()));

                lista.add(trabajo);
            } while (cursor.moveToNext());
        }
        else {
            cursor.close();
        }
        db.close();

        return lista;
    }



    protected void lanzarTrabajo(String trabajo) {
        Intent tarea = new Intent(this,Layout_Trabajo.class);
        tarea.putExtra("trabajo",trabajo);
        startActivity(tarea);
        finish();
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == COMANDOS_PORVOZ_ID && resultCode == RESULT_OK) {
            String trabajoReconocido;
            ArrayList<String> palabrasObtenidasPorVoz = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            boolean similitudEncontrada = false;
            StringBuilder listaPalabras = new StringBuilder();

            for ( String palabra : palabrasObtenidasPorVoz ) {
                 listaPalabras.append(palabra).append(",");
                 trabajoReconocido = Eudex.simcontains(listaTrabajos, palabra);

                 if (!trabajoReconocido.isEmpty()) {
                    similitudEncontrada = true;
                    lanzarTrabajo(trabajoReconocido);

                }
            }

            if(!similitudEncontrada) {
                Toast.makeText(getApplicationContext(),
                        listaPalabras + "Trabajo no encontrado", Toast.LENGTH_LONG).show();
                reconocerVoz("Por favor, pronuncia fuerte y claro el trabajo requieres.");
            }
            super.onActivityResult(requestCode, resultCode, data);
        }
    }


}
